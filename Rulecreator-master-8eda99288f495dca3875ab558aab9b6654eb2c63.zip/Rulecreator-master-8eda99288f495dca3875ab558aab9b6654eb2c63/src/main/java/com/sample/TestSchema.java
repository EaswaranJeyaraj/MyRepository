package com.sample;


import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;

/**
 * Created by sinchan on 03/09/17.
 */
public class TestSchema {

    public static void main(String[] args) {
        String xml ="<?xml version=\"1.0\"?>\n" +
                "<root>\n" +
                "    <package>com.mundio.drools</package>\n" +
                "    <import>com.mundio.Cheese</import>\n" +
                "    <import>com.mundio.Person</import>\n" +
                "    <rule name=\"Rule1\">\n" +
                "        <lhs>\n" +
                "            <pattern class='Cheese'>\n" +
                "                <id>cheese</id>\n" +
                "                <constraint>type='stilton'</constraint>\n" +
                "                <constraint>price=10</constraint>\n" +
                "            </pattern>\n" +
                "            <pattern class='ArrayList'>\n" +
                "                <from>\n" +
                "                    <collect>\n" +
                "                        <pattern class='Person'>\n" +
                "                            <constraint>age=2</constraint>\n" +
                "                        </pattern>\n" +
                "                    </collect>\n" +
                "                </from>\n" +
                "            </pattern>\n" +
                "            <pattern class='StockTick'>\n" +
                "                <from>\n" +
                "                    <accumulate>\n" +
                "                        <source>\n" +
                "                            <pattern class='StockTick'>\n" +
                "                                <constraint>company='RHT'</constraint>\n" +
                "                                <bind>\n" +
                "                                    <var>vPrice</var>\n" +
                "                                    <val>price</val>\n" +
                "                                </bind>\n" +
                "                            </pattern>\n" +
                "                        </source>\n" +
                "\n" +
                "                    </accumulate>\n" +
                "                </from>\n" +
                "\n" +
                "            </pattern>\n" +
                "        </lhs>\n" +
                "        <rhs>\n" +
                "            <mail>dmail@gmail.com</mail>\n" +
                "            <mobile>909764567</mobile>\n" +
                "            <sendSMS>Y</sendSMS>\n" +
                "            <sendSMSdetail>sms body content</sendSMSdetail>\n" +
                "            <sendMail>Y</sendMail>\n" +
                "            <sendMaildetail>mail body content</sendMaildetail>\n" +
                "            <actionwrapper>cheese</actionwrapper>\n" +
                "        </rhs>\n" +
                "    </rule>\n" +
                "</root>\n";

        validateXMLSchema("src/main/resources/sample.xsd",xml);
    }

    public static boolean validateXMLSchema(String xsdPath, String xmlPath){

        try {
            SchemaFactory factory =
                    SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new File(xsdPath));
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(new StringReader(xmlPath)));
        } catch (Exception e) {
            System.out.println("Exception: "+e.getMessage());
            return false;
        }
        return true;
    }
}
