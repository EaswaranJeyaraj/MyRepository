package com.sample;

import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeSpec;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.lang.model.element.Modifier;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.DataInputStream;
import java.io.StringReader;

/**
 * Created by sinchan on 28/08/17.
 */
public class ClassGeneratorOld {

    public static void main(String[] args) {
        MethodSpec main = MethodSpec.methodBuilder("main")
                .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
                .returns(void.class)
                .addParameter(String[].class, "args")
                .addStatement("String drl = execute(args[0])")
                .addStatement("System.out.println(drl)")
                .build();
        MethodSpec.Builder excuteMethodBuilder = MethodSpec.methodBuilder("execute")
                .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
                .returns(String.class);
        String generatedClassName = "";
        DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
        try{
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader("<?xml version=\"1.0\"?> <root> <package>com.mundio.drools</package> <import>com.mundio.Cheese </import> <import>com.mundio.Person</import><rule>Rule1</rule><lhs></lhs></root>"));//"<xml> <package>com.mundio.drools</package> <import>com.mundio.Cheese </import> <import>com.mundio.Person</import><rule>Rule1</rule><lhs></lhs></xml>"
            Document document=builder.parse(is);
            Element documentElement=document.getDocumentElement();
            System.out.println("doc:" + documentElement.getNodeName());
            NodeList rootsChildNodes = documentElement.getChildNodes();
            StringBuffer packagedescrString = new StringBuffer("DescrFactory");
            System.out.print("lenght:" + rootsChildNodes.getLength());
            for(int i=0;i<rootsChildNodes.getLength();i++){
                Node currNode = rootsChildNodes.item(i);
                if(currNode.getNodeType()==Node.ELEMENT_NODE){
                    String value = currNode.getTextContent();
                    String nodeName = currNode.getNodeName();
                    if(nodeName.equalsIgnoreCase("package")){
                        System.out.println("inside: "+currNode.getFirstChild().getNodeValue());
                        value=currNode.getFirstChild().getNodeValue();
                        packagedescrString.append(".newPackage().name(\"").append(value).append("\")");
                    }
                    if(nodeName.equalsIgnoreCase("import")){
                        value=currNode.getFirstChild().getNodeValue();
                        packagedescrString.append(".newImport().target(\"").append(value).append("\").end()");
                    }
                    if(nodeName.equalsIgnoreCase("rule")){
                        value=currNode.getFirstChild().getNodeValue();
                        packagedescrString.append(".newRule().name(\"").append(value).append("\")");
                        generatedClassName = value.replace(" ","_");
                    }

                }else if(currNode.getNodeType()==Node.ELEMENT_NODE){

                    String nodeName = currNode.getNodeName();
                    if(nodeName.equalsIgnoreCase("lhs")){
                        packagedescrString.append(".lhs()");
                        NodeList lhsChildren = currNode.getChildNodes();
                        for(int index=0;index<lhsChildren.getLength();index++){
                            Node currLhsNode = lhsChildren.item(index);
                           if(currLhsNode.getNodeType()==Node.ELEMENT_NODE){
                                if(currLhsNode.getNodeName().equalsIgnoreCase("OR")){
                                    packagedescrString.append("or()");
                                }
                                if(currLhsNode.getNodeName().equalsIgnoreCase("AND")){
                                    packagedescrString.append("and()");
                                }
                                if(currLhsNode.getNodeName().equalsIgnoreCase("pattern")){
                                    String clazz=currLhsNode.getAttributes().getNamedItem("class").getNodeValue();
                                    packagedescrString.append(".pattern(\"").append(clazz).append("\")");
                                    NodeList patternChildren = currLhsNode.getChildNodes();

                                    for(int patternCounter=0;patternCounter < patternChildren.getLength(); patternCounter++){
                                        Node currPatterChild = patternChildren.item(patternCounter);

                                        if(currPatterChild.getNodeType()==Node.TEXT_NODE){
                                            if(currPatterChild.getNodeName().equalsIgnoreCase("constraint")){
                                                packagedescrString.append(".constraint(\"").append(currPatterChild.getNodeValue()).append("\")");
                                            }
                                            if(currPatterChild.getNodeName().equalsIgnoreCase("id")){
                                                packagedescrString.append(".id(\"").append(currPatterChild.getNodeValue()).append("\")");
                                            }

                                        }
                                        else if(currPatterChild.getNodeType()==Node.ELEMENT_NODE){
                                           if(currPatterChild.getNodeName().equalsIgnoreCase("bind")){
                                               packagedescrString.append("bind(");

                                               NodeList bindChildren = currPatterChild.getChildNodes();
                                                for(int j=0;j<bindChildren.getLength();j++){
                                                    Node currBindChild = bindChildren.item(j);
                                                    if(currBindChild.getNodeType()==Node.TEXT_NODE){
                                                        if(currBindChild.getNodeName().equalsIgnoreCase("var")){
                                                            packagedescrString.append("\"").append(currBindChild.getNodeValue()).append("\"");
                                                        }
                                                        else if (currBindChild.getNodeName().equalsIgnoreCase("value")){
                                                            packagedescrString.append(",").append("\"").append(currBindChild.getNodeValue()).append("\"");
                                                            packagedescrString.append(",").append("false");

                                                        }
                                                    }
                                                }
                                               packagedescrString.append(")");

                                           }
                                            else if(currPatterChild.getNodeName().equalsIgnoreCase("from")){
                                               NodeList fromChildren = currPatterChild.getChildNodes();
                                               Node fromChild = fromChildren.item(0);
                                               if(fromChild.getNodeName().equalsIgnoreCase("collect")){
                                                   //TODO: get collect children as pattern
                                                  //pattern with only bind,id and constraint
                                               }
                                               else if(fromChild.getNodeName().equalsIgnoreCase("accumulate")){
                                                   //TODO: get accumulate children as pattern and functions
                                                   //pattern with only bind,id and contraint
                                               }

                                           }
                                        }
                                    }

                                    packagedescrString.append(".end()");
                                }
                            }
                        }
                        packagedescrString.append(".end()");
                    }else if (nodeName.equalsIgnoreCase("rhs")){

                    }
                }

            }

            packagedescrString.append(".getDescr()");
            excuteMethodBuilder.addStatement(packagedescrString.toString());
            excuteMethodBuilder.addStatement("String drl = new DrlDumper().dump( pkg )");
            excuteMethodBuilder.addStatement("return drl");

            System.out.println(generatedClassName);
            TypeSpec classFile = TypeSpec.classBuilder(generatedClassName)
                    .addModifiers(Modifier.PUBLIC, Modifier.FINAL)
                    .addMethod(main)
                    .addMethod(excuteMethodBuilder.build())
                    .build();

            JavaFile javaFile = JavaFile.builder("com.rulegenerator.generated", classFile)
                    .build();

            javaFile.writeTo(System.out);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
