package com.sample;

import org.drools.compiler.lang.DrlDumper;
import org.drools.compiler.lang.api.DescrFactory;
import org.drools.compiler.lang.descr.PackageDescr;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by sinchan on 31/07/17.
 */
public class TestMain {

    public static void main(String[] args) throws IOException {
       // final PackageBuilder builder = new PackageBuilder();
        PackageDescr pkg = DescrFactory.newPackage()
                .name( "org.drools.compiler" )
                .newImport().target("com.mundio.Cheese").end()
                .newImport().target("com.mundio.Person").end()
                .newFunctionImport().target("com.mundio.utility.Functionclass.function").end()
                .newRule().name( "test" )
                .lhs()
                .pattern("Cheese").id("$cheese",false).constraint( "type == \"stilton\"" ).constraint("price < 10").end()
                .pattern("ArrayList").constraint("size > 3").from().collect().pattern("Person").constraint("age>22").end().end().end()
                .accumulate()
                .source()
                .pattern("StockTick").constraint( "company == \"RHT\"" ).bind( "$p", "price", false ).end()
                .end()

                .function( "sum", "$sum", false, "$p" )
                .function( "count", "$cnt", false, "$p" )
                .end()
                .conditionalBranch()
                .condition().constraint("price < 10").end()
                .consequence().name("c1").end()
                .end()
                .pattern("Cheese").constraint( "type == \"cheddar\"" ).end()
                .end()
                .rhs( "$cheese.sendSMS=\"Y\"\n$cheese.SMS=\"Hello\"")
                .rhs("blah blah")
                .namedRhs( "c1", "// do something else" )
                .end()
                .getDescr();
        String drl = new DrlDumper().dump( pkg );
        FileWriter writer = new FileWriter("src/main/resources/XyzRule.drl");
        writer.write(drl);
        writer.flush();
        writer.close();
        System.out.println(drl);
    }
}
