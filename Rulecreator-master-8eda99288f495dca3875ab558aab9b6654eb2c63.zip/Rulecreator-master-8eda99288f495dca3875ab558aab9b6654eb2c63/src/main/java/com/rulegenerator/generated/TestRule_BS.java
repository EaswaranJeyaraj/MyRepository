package com.rulegenerator.generated;

import java.io.FileWriter;
import java.lang.Exception;
import java.lang.String;
import org.drools.compiler.lang.DrlDumper;
import org.drools.compiler.lang.api.DescrFactory;
import org.drools.compiler.lang.descr.PackageDescr;

public final class TestRule_BS {
  public static final String DRL_FILE_PATH = "C:/RuleEditorBackend/droolsrule/src/main/resources/rules/TestRule_BS.drl";

  public static void main(String[] args) throws Exception {
    String drl = execute();
    FileWriter writer = new FileWriter(DRL_FILE_PATH);
    writer.write(drl);
    writer.flush();
    writer.close();
    System.out.println(drl);
  }

  public static String execute() {
    PackageDescr pkg = DescrFactory.newPackage().name("com.mundio.drools").newImport().target("java.lang.Number").end().newImport().target("com.mundio.drools.model.BundleCases").end().newImport().target("com.mundio.drools.model.BundleEvent").end().newImport().target("com.mundio.drools.model.BundleLog").end().newImport().target("com.mundio.drools.model.MvNoBundlePlan").end().newImport().target("com.mundio.drools.model.Package").end().newImport().target("com.mundio.drools.model.TopupLog").end().newImport().target("com.mundio.drools.model.Action").end().newImport().target("java.util.ArrayList").end().newRule().name("TestRule_BS").attribute("dialect","mvel").lhs().pattern("BundleCases").id("vBundleCases",false).constraint("event.actionType == 'subscribebundle'").constraint("event.status == 1").constraint("event.mvbpStatus == 1").constraint("event.updateBy in ( 'WEB', 'VMCZ Website', 'Web CRM3', 'USSD' )").constraint("event.currCode == 'CZK'").bind("vEvent","event != null",false).bind("vMobile","mobileNo != null",false).bind("vEmail","email != null",false).bind("vBundlelogs","bundlelogs != null",false).end().pattern("ArrayList").constraint("size() >= 2").from().collect().pattern("BundleLog").constraint("bundleID == vEvent.bundleID").constraint("processName == 'subscribe'").constraint("bundleLogstatus == 0").from().expression("vBundlelogs").end().end().end().end().rhs("Action vAction = new Action()\nvAction.email=vEmail\nvAction.mobileNo=vMobile\nvAction.sendSms=\"Y\"\nvAction.sendSmsDetail=\"Dear Customer, you can now easily subscribe for the Auto-Renewal option by going to our website vectonemobile.cz\"\nvAction.sendMail=\"Y\"\nvAction.sendMailDetail=\"Dear Customer, you can now easily subscribe for the Auto-Renewal option by going to our website vectonemobile.cz\"\nvBundleCases.action=vAction").end().getDescr();
    return new DrlDumper().dump( pkg );
  }
}
