package com.mundio.ruleeditor.domain;

import java.util.Date;

/**
 * Created by sinchan on 03/09/17.
 */
public class JobInfo {

    private String jobId;
    private String ruleName;
    private String status;
    private Date logDate;

    public JobInfo() {
    }


    public JobInfo(String jobId, String ruleName, String status, Date logDate) {
        this.jobId = jobId;
        this.ruleName = ruleName;
        this.status = status;
        this.logDate = logDate;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getLogDate() {
        return logDate;
    }

    public void setLogDate(Date logDate) {
        this.logDate = logDate;
    }
}
