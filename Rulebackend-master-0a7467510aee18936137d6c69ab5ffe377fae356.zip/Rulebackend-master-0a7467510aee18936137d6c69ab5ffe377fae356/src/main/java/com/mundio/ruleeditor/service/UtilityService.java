package com.mundio.ruleeditor.service;

import com.mundio.ruleeditor.domain.UtilityResponse;
import com.mundio.ruleeditor.repository.ModelDao;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by sinchan on 24/08/17.
 */
@Service
public class UtilityService {

    @Autowired
    ModelDao modelDao;

    @Autowired
    CacheManager cacheManager;

    @PostConstruct
    public void init() {
        update();
    }

    public void update() {
        for (Class clazz : modelDao.getAllUtils()) {
            Method[] methods = clazz.getMethods();
            for (Method method: methods){
                if((method.getModifiers() & Modifier.STATIC)!=0){
                    //TO_DO:
                    String importStatement = method.getDeclaringClass().getName()+"."+method.getName();
                    cacheManager.getCache("utilities").put(importStatement,method);
                }
            }
        }
    }

    public List<UtilityResponse> getAllUtilities() throws IOException {
        //ClassPath p = ClassPath.from(ClassLoader.getSystemClassLoader()); // might need to provide different ClassLoader
        //ImmutableSet<ClassPath.ClassInfo> classes = p.getTopLevelClassesRecursive("com.mundio.drools");
        //p.getAllClasses()
        Ehcache ehcache = (Ehcache)cacheManager.getCache("utilities").getNativeCache();
        List<UtilityResponse> utilities = new ArrayList<>();

        for(Object key: ehcache.getKeys()){
            UtilityResponse response = new UtilityResponse();
           response.setImportValue((String)key);
            Element valueElement = ehcache.get(key);
            Method method = (Method) valueElement.getObjectValue();
            response.setFunctionname(method.getName());
            StringBuffer parametersTypes = new StringBuffer();
            boolean isFirstTraversed = false;
            for(Class clazz :method.getParameterTypes()){
                if(isFirstTraversed){
                    parametersTypes.append(",");
                }

                    parametersTypes.append(clazz.getName());


                if(!isFirstTraversed){
                    isFirstTraversed=true;
                }
            }
            response.setParamTypes(parametersTypes.toString());
            utilities.add(response);
        }
        return utilities;
    }


}
