package com.mundio.ruleeditor.domain;

/**
 * Created by sinchan on 03/09/17.
 */
public class RuleName {
    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
