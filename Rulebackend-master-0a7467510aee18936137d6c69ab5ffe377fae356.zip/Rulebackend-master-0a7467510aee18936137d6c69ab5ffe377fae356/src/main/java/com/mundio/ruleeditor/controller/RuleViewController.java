package com.mundio.ruleeditor.controller;


import com.mundio.ruleeditor.domain.CreationResponse;
import com.mundio.ruleeditor.domain.RuleDetailsInfo;
import com.mundio.ruleeditor.domain.RuleName;
import com.mundio.ruleeditor.exception.RuleViewerException;
import com.mundio.ruleeditor.service.RuleViewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by sinchan on 26/08/17.
 */
@RequestMapping("/ruleviewer")
@RestController
public class RuleViewController {

    @Autowired
    private RuleViewService ruleViewService;

    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/viewAll",produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
    public ResponseEntity<List<RuleName>> getAllRules(){
        List<RuleName> rules= null;
        try {
            rules = ruleViewService.getAllRules();
        }catch (Exception ex){
            return new ResponseEntity(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if(rules==null){
            return new ResponseEntity<List<RuleName>>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<List<RuleName>>(rules,HttpStatus.OK);
    }


    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/view",produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
    public ResponseEntity<RuleDetailsInfo> vieRule(@RequestParam("ruleName") String ruleName){
        RuleDetailsInfo detailsInfo = null;
        try {
            detailsInfo = ruleViewService.getRule(ruleName);
        }catch (RuleViewerException viewex){
            detailsInfo = new RuleDetailsInfo();
            detailsInfo.setMessage(viewex.getMessage());
            return new ResponseEntity<RuleDetailsInfo>(detailsInfo,HttpStatus.EXPECTATION_FAILED);

        }
        catch (Exception e){
            return new ResponseEntity<RuleDetailsInfo>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<RuleDetailsInfo>(detailsInfo,HttpStatus.OK);
    }

}
