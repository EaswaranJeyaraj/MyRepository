package com.mundio.ruleeditor.exception;

/**
 * Created by sinchan on 31/08/17.
 */
public class RuleCreationException extends RuntimeException {

    public RuleCreationException(String message) {
        super(message);
    }

    public RuleCreationException(String message, Throwable cause) {
        super(message, cause);
    }
}
