package com.mundio.ruleeditor.service;

import com.mundio.ruleeditor.domain.RuleDetailsInfo;
import com.mundio.ruleeditor.domain.RuleName;
import com.mundio.ruleeditor.repository.AuditDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sinchan on 03/09/17.
 */
@Service
public class RuleViewService {

    @Autowired
    AuditDao auditDao;

    public List<RuleName> getAllRules(){
        List<RuleName> ruleNames = new ArrayList<>();

          auditDao.getAllRuleNames().forEach(ruleName ->{
              RuleName ruleNameObj = new RuleName();
              ruleNameObj.setName(ruleName);
              ruleNames.add(ruleNameObj);
          } );

          return ruleNames;

    }


    public RuleDetailsInfo getRule(String ruleName){

        return auditDao.getRule(ruleName);

    }

}
