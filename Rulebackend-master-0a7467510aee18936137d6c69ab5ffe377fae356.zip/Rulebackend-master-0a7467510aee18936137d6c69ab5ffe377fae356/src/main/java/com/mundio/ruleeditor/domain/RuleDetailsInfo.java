package com.mundio.ruleeditor.domain;

import java.util.Date;

/**
 * Created by sinchan on 03/09/17.
 */
public class RuleDetailsInfo {

    private int ruleId;
    private String ruleName ;
    private String ruleXml ;
    private Date createdDateTime;
    private Date modifiedDateTime;
    private String message;
    private String delFlag;

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public RuleDetailsInfo() {
    }

    public RuleDetailsInfo(int ruleId, String ruleName, String ruleXml, Date createdDateTime, Date modifiedDateTime) {
        this.ruleId = ruleId;
        this.ruleName = ruleName;
        this.ruleXml = ruleXml;
        this.createdDateTime = createdDateTime;
        this.modifiedDateTime = modifiedDateTime;
    }

    public int getRuleId() {
        return ruleId;
    }

    public void setRuleId(int ruleId) {
        this.ruleId = ruleId;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getRuleXml() {
        return ruleXml;
    }

    public void setRuleXml(String ruleXml) {
        this.ruleXml = ruleXml;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public Date getModifiedDateTime() {
        return modifiedDateTime;
    }

    public void setModifiedDateTime(Date modifiedDateTime) {
        this.modifiedDateTime = modifiedDateTime;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
