package com.mundio.ruleeditor.controller;

import com.mundio.ruleeditor.domain.CreationResponse;
import com.mundio.ruleeditor.exception.RuleCreationException;
import com.mundio.ruleeditor.exception.XmlValidationException;
import com.mundio.ruleeditor.service.RuleCreationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;

/**
 * Created by sinchan on 26/08/17.
 */
@RequestMapping("/rulewriter")
@RestController
public class RuleCreationController {

    @Autowired
    private RuleCreationService ruleCreationService;

    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/create", consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<CreationResponse> createRule(@RequestBody String ruleXml) {


        String jobId = "";
        CreationResponse creationResponse = new CreationResponse();
        try {
            jobId = ruleCreationService.createRule(ruleXml);
        } catch (RuleCreationException ruleEx) {
            creationResponse.setStatus("NOT_SUBMITTED");
            creationResponse.setMessage(ruleEx.getMessage());
            return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.EXPECTATION_FAILED);

        } catch (XmlValidationException validex) {
            creationResponse.setStatus("NOT_SUBMITTED");
            creationResponse.setMessage("XML Validation failed: " + validex.getMessage());
            return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            creationResponse.setStatus("NOT_SUBMITTED");
            creationResponse.setMessage(e.getMessage());
            return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        }
        if (jobId.equalsIgnoreCase("NA")) {
            creationResponse.setStatus("NOT_SUBMITTED");
            creationResponse.setMessage("Reason Unknown");
            return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        creationResponse.setStatus("SUBMITTED");
        creationResponse.setJobId(jobId);
        return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.CREATED);
        //result.setResult(ResponseEntity.ok(now()));

    }

    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/check", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    public ResponseEntity<CreationResponse> checkRuleCreation(@RequestParam("jobId") String jobId) {
        CreationResponse creationResponse = new CreationResponse();
        try {
            creationResponse = ruleCreationService.checkRuleCreation(jobId);
        } catch (Exception e) {
            creationResponse.setStatus("HTTP_ERROR");
            creationResponse.setMessage(e.getMessage());
            return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.OK);
    }


    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/delete", consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<CreationResponse> deleteRule(@RequestParam("ruleName") String ruleName) {

        CreationResponse creationResponse = new CreationResponse();
        try {
            creationResponse = ruleCreationService.deleteRule(ruleName);
        }
        catch (Exception e) {
            creationResponse.setStatus("HTTP_ERROR");
            creationResponse.setMessage(e.getMessage());
            return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        }
             return new ResponseEntity<CreationResponse>(creationResponse, HttpStatus.CREATED);
        //result.setResult(ResponseEntity.ok(now()));

    }

}