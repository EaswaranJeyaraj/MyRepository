package com.mundio.ruleeditor.domain;

/**
 * Created by sinchan on 03/09/17.
 */
public class UtilityResponse {

    private String paramTypes;
    private String functionname;
    private String importValue;

    public String getParamTypes() {
        return paramTypes;
    }

    public void setParamTypes(String paramTypes) {
        this.paramTypes = paramTypes;
    }

    public String getFunctionname() {
        return functionname;
    }

    public void setFunctionname(String functionname) {
        this.functionname = functionname;
    }

    public String getImportValue() {
        return importValue;
    }

    public void setImportValue(String importValue) {
        this.importValue = importValue;
    }
}
