package com.mundio.ruleeditor.exception;

/**
 * Created by sinchan on 31/08/17.
 */
public class XmlValidationException extends RuntimeException {

    public XmlValidationException(String message) {
        super(message);
    }

    public XmlValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
