package com.mundio.ruleeditor.repository;

import com.google.common.collect.ImmutableSet;
import com.google.common.reflect.ClassPath;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sinchan on 26/08/17.
 */
@Repository
public class ModelDao {

    @Value("${modeljar.path}")
    String modelJarFilePath;

    public List<Class> getAllModels() {
        List<Class> models = new ArrayList<>();
        try {
            ClassLoader loader = URLClassLoader.newInstance(
                    new URL[] { new URL(modelJarFilePath) },
                    getClass().getClassLoader()
            );
            ClassPath p = ClassPath.from(loader); // might need to provide different ClassLoader
            ImmutableSet<ClassPath.ClassInfo> classes = p.getTopLevelClassesRecursive("com.mundio.drools.model");
            //p.getAllClasses()
            System.out.println("classes: "+ classes);
            for (ClassPath.ClassInfo classInfo : classes) {
                Class clazz = classInfo.load();
                models.add(clazz);
            }
        }catch (IOException ex){
            ex.printStackTrace();
        }
        return models;
    }


    public List<Class> getAllUtils() {
        List<Class> utils = new ArrayList<>();
        try {
            ClassLoader loader = URLClassLoader.newInstance(
                    new URL[] { new URL(modelJarFilePath) },
                    getClass().getClassLoader()
            );
            ClassPath p = ClassPath.from(loader); // might need to provide different ClassLoader
            ImmutableSet<ClassPath.ClassInfo> classes = p.getTopLevelClassesRecursive("com.mundio.drools.customfunction");
            //p.getAllClasses()
            for (ClassPath.ClassInfo classInfo : classes) {
                Class clazz = classInfo.load();
                utils.add(clazz);
            }
        }catch (IOException ex){
            ex.printStackTrace();
        }
        return utils;
    }
}
