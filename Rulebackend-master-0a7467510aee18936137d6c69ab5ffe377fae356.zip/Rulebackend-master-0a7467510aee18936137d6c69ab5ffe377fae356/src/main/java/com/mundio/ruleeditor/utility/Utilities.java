package com.mundio.ruleeditor.utility;

import com.mundio.ruleeditor.domain.ValidationResult;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.File;
import java.io.StringReader;

/**
 * Created by sinchan on 04/09/17.
 */
public enum Utilities {

    INSTANCE;

    public ValidationResult validateXMLSchema(String xsdPath, String xml){

        try {
            SchemaFactory factory =
                    SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new File(xsdPath));
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(new StringReader(xml)));
        } catch (Exception e) {
            String exceptionMessage = "Exception: " + e.getMessage();
            System.out.println(exceptionMessage);

            return new ValidationResult(false,exceptionMessage);
        }
        return new ValidationResult(true);
    }
}
