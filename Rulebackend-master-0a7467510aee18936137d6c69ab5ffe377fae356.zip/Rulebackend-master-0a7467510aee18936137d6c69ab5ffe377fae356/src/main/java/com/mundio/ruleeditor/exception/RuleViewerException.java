package com.mundio.ruleeditor.exception;

/**
 * Created by sinchan on 31/08/17.
 */
public class RuleViewerException extends RuntimeException {

    public RuleViewerException(String message) {
        super(message);
    }

    public RuleViewerException(String message, Throwable cause) {
        super(message, cause);
    }
}
