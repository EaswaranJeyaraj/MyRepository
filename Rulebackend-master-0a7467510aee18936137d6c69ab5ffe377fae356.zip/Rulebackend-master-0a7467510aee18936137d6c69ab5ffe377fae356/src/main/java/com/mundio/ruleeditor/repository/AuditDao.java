package com.mundio.ruleeditor.repository;

import com.mundio.ruleeditor.domain.JobInfo;
import com.mundio.ruleeditor.domain.RuleDetailsInfo;
import com.mundio.ruleeditor.exception.RuleCreationException;
import com.mundio.ruleeditor.exception.RuleViewerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

/**
 * Created by sinchan on 31/08/17.
 */
@Repository
public class AuditDao {

      @Autowired
      private JdbcTemplate jdbcTemplate;


    /*
     *
     * job_id NUMBER(10) NOT NULL AUTO_INCREMENT,
   rule_name VARCHAR(100) NOT NULL,
   status VARCHAR(40) NOT NULL,
   Created_date_Time DATE,
   modified_date_Time DATE
     */
    //insert job, update job, insert xml, select job
    @Transactional("transactionManager")
      public void insertJob(JobInfo jobInfo){
          jdbcTemplate.update(
                  "INSERT INTO Job_Details_tbl (job_id, rule_name, status,Created_date_Time) VALUES (?, ?, ?, ?)",
                  new Object[]{jobInfo.getJobId(), jobInfo.getRuleName(),jobInfo.getStatus(),jobInfo.getLogDate()}
          );

      }

    @Transactional("transactionManager")
    public void updateJob(JobInfo jobInfo){
        jdbcTemplate.update(
                "UPDATE Job_Details_tbl SET status = ? , modified_date_Time = ? WHERE job_id = ?",
                new Object[]{jobInfo.getStatus(), jobInfo.getLogDate(), jobInfo.getJobId()}
        );

    }


    public String getStatus(String jobId){
        List<String> statuses =  jdbcTemplate.query("select status FROM Job_Details_tbl where job_id = ?", new Object[]{jobId}, new RowMapper<String>() {

            @Override
            public String mapRow(ResultSet resultSet, int i) throws SQLException {

                return resultSet.getString("status");
            }
        });

        if (statuses==null || statuses.isEmpty() || statuses.size()<=0){
            throw new RuleCreationException("Rule creation job not found for job id:"+jobId);
        }
        return statuses.get(0);
    }

    /*
    CREATE TABLE Rule_Details_tbl
(  rule_id NUMBER(10) NOT NULL AUTO_INCREMENT,
   rule_name VARCHAR(100) NOT NULL,
   rule_xml VARCHAR(2000) NOT NULL,
   Created_date_Time DATE,
   modified_date_Time DATE,
   job_id NUMBER(10) INT NOT NULL,
   FOREIGN_KEY (job_id),
   PRIMARY_KEY ( rule_id )
);

     */

    @Transactional("transactionManager")
    public void saveorUpdateRule(RuleDetailsInfo ruleDetailsInfo){
        List<Integer> ruleIds = jdbcTemplate.query("select rule_id FROM Rule_Details_tbl where rule_name = ?", new Object[]{ruleDetailsInfo.getRuleName()}, new RowMapper<Integer>() {

            @Override
            public Integer mapRow(ResultSet resultSet, int i) throws SQLException {

                return (resultSet==null || resultSet.wasNull())?0:resultSet.getInt("rule_id");
            }
        });
        if(!ruleIds.isEmpty() && ruleIds.size()> 0){
            int ruleId = ruleIds.get(0);
            if(ruleId>0){
                jdbcTemplate.update(
                        "update  Rule_Details_tbl SET rule_xml= ? , modified_date_Time = ? where rule_id = ?",
                        new Object[]{ruleDetailsInfo.getRuleXml(), ruleDetailsInfo.getModifiedDateTime(),ruleId}
                );
            }
        }

        else {
            jdbcTemplate.update(
                    "INSERT INTO Rule_Details_tbl (rule_name, rule_xml,Created_date_Time) VALUES (?, ?, ?)",
                    new Object[]{ruleDetailsInfo.getRuleName(), ruleDetailsInfo.getRuleXml(),ruleDetailsInfo.getModifiedDateTime()}
            );
        }

    }


    @Transactional("transactionManager")
    public void deleteRule(RuleDetailsInfo ruleDetailsInfo){
        jdbcTemplate.update(
                "update  Rule_Details_tbl SET Del_Flag= ? , modified_date_Time = ? where rule_name = ?",
                new Object[]{ruleDetailsInfo.getDelFlag(), ruleDetailsInfo.getModifiedDateTime(),ruleDetailsInfo.getRuleName()}
        );

    }

    public List<String> getAllRuleNames(){
        return  jdbcTemplate.query("select rule_name from Rule_Details_tbl", new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet resultSet, int i) throws SQLException {
                return resultSet.getString("rule_name");
            }
        });
    }



    public  RuleDetailsInfo getRule(String ruleName){

       List<RuleDetailsInfo> results = jdbcTemplate.query("select rule_id,rule_name,rule_xml,Created_date_Time,modified_date_time,Del_Flag from Rule_Details_tbl where rule_name = ?", new Object[]{ruleName}, new RowMapper<RuleDetailsInfo>() {

            @Override
            public RuleDetailsInfo mapRow(ResultSet resultSet, int i) throws SQLException {
                RuleDetailsInfo info = new RuleDetailsInfo();
                info.setRuleId(resultSet.getInt("rule_id"));
                info.setRuleName(resultSet.getString("rule_name"));
                info.setRuleXml(resultSet.getString("rule_xml"));
                info.setCreatedDateTime(resultSet.getDate("Created_date_Time"));
                info.setModifiedDateTime(resultSet.getDate("modified_date_time"));
                info.setDelFlag(resultSet.getString("Del_Flag"));
                return info;
            }
        });

       if(results==null || results.isEmpty() || results.size()<=0){
           throw new RuleViewerException("Rule defination not available for Rule Name = '"+ ruleName +"'");
       }

       return results.get(0);
    }

}
