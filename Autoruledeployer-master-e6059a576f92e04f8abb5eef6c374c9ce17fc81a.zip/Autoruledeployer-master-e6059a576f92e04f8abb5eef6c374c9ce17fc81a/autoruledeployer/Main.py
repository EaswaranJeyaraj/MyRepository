import time
import sys
from watchdog.observers import Observer
from watchdog.events import PatternMatchingEventHandler
import pysftp
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None
class DrlWatcherHandler(PatternMatchingEventHandler):
    pattern = ["*.drl"]

    def process(self, event):
        print(event.src_path,event.event_type)
        try:
            with pysftp.Connection('10.22.3.52',username='root',password='vicarage2000', cnopts=cnopts) as sftp:
                with sftp.cd('/root/RuleEngine/droolsrule/src/main/resources/rules'):

                    if event.event_type == 'deleted':
                        filename = event.src_path[len("C:/RuleEditorBackend/droolsrule/src/main/resources/rules/"):len(event.src_path)]
                        sftp.remove(filename)
                    else:
                        sftp.put(event.src_path)

                    sftp.close()
        except:
            print("Except in sftp")

    def on_created(self, event):
        self.process(event)

    def on_modified(self, event):
        self.process(event)

    def on_deleted(self, event):
        self.process(event)


if __name__ == '__main__':
    args = sys.argv[1:]
    observer = Observer()
    observer.schedule(DrlWatcherHandler(), path=args[0] if args else '.')
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Except",KeyboardInterrupt)
        observer.stop()

    observer.join()

