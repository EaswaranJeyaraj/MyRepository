package com.mundio.mat

import java.nio.ByteBuffer
import java.sql.DriverManager
import java.text.SimpleDateFormat
import java.util
import java.util.{Calendar, Date}

import com.google.gson.{Gson, GsonBuilder}
import com.mundio.rules._
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.spark.rdd.RDD

/**
  * Created by sinchan on 27-12-2016.
  */
object HBaseUtility {

  def populatePuts(key: String, json: String):  Put = {

      val facts = (new Gson()).fromJson(json, classOf[Facts])
      val put = new Put((key + System.currentTimeMillis.toString).getBytes)
      put.addImmutable("cf".getBytes(), "app".getBytes(), facts.getApp.getBytes())
      put.addImmutable("cf".getBytes(), "version".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getVersion).array())
      //put.addImmutable("cf".getBytes(),"app".getBytes(),trynow.)

      put

  }

  def populateBundlePuts(key: String, json:String): Put = {

      val gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create()
      val facts = gson.fromJson(json, classOf[BundleEvent])
      val format = new java.text.SimpleDateFormat("dd-MM-yyyy hh:mm:ss")
      val r = new scala.util.Random
      val regionTag = (97 + r.nextInt(( 100 - 97) + 1)).toChar
      val put = new Put((regionTag + "-"+key +"-"+ facts.getSubscriberID+facts.getBundleID+"-" + (Long.MaxValue - System.currentTimeMillis).toString).getBytes)




      // Subscriber Table

      if (facts.getSubscriberID != 0) {
        put.addImmutable("bundle".getBytes(), "subscriberID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getSubscriberID).array()) //integer
      }

      if (facts.getFirstName != null) {
        put.addImmutable("bundle".getBytes(), "firstName".getBytes(), facts.getFirstName.getBytes()) // String
      }
      if (facts.getLastName != null) {
        put.addImmutable("bundle".getBytes(), "lastName".getBytes(), facts.getLastName.getBytes()) // String
      }
      if (facts.getEmail != null) {
        put.addImmutable("bundle".getBytes(), "email".getBytes(), facts.getEmail.getBytes()) // String
      }
      if (facts.getActivationDate != null) {
        put.addImmutable("bundle".getBytes(), "activationDate".getBytes(), format.format(facts.getActivationDate).getBytes()) //date
      }


      // bundle plan
      if (facts.getBundleID != 0) {
        put.addImmutable("bundle".getBytes(), "bundleID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getBundleID).array()) //integer
      }
      if (facts.getSiteCode != null) {
        put.addImmutable("bundle".getBytes(), "siteCode".getBytes(), facts.getSiteCode.getBytes()) // String
      }
      if (facts.getBundleName != null) {
        put.addImmutable("bundle".getBytes(), "bundleName".getBytes(), facts.getBundleName.getBytes()) // String
      }
      if (facts.getPrice != 0.0) {
        put.addImmutable("bundle".getBytes(), "price".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getPrice).array()) //double
      }
      if (facts.getCurrency != null) {
        put.addImmutable("bundle".getBytes(), "currency".getBytes(), facts.getCurrency.getBytes()) // String
      }
      if (facts.getStatus != 0) {
        put.addImmutable("bundle".getBytes(), "status".getBytes(), ByteBuffer.allocate(4).putInt(facts.getStatus).array())
      }
      if (facts.getRenewalMode != 0) {
        put.addImmutable("bundle".getBytes(), "renewalMode".getBytes(), ByteBuffer.allocate(4).putInt(facts.getRenewalMode).array())
      }
      if (facts.getRenewalDelay != 0) {
        put.addImmutable("bundle".getBytes(), "renewalDelay".getBytes(), ByteBuffer.allocate(4).putInt(facts.getRenewalDelay).array())
      }
      if (facts.getMainBundleGroupID != 0) {
        put.addImmutable("bundle".getBytes(), "mainBundleGroupID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getMainBundleGroupID).array())
      }
      if (facts.getFamilyGroupID != 0) {
        put.addImmutable("bundle".getBytes(), "familyGroupID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getFamilyGroupID).array())
      }
      if (facts.getTariffClassGroupID != 0) {
        put.addImmutable("bundle".getBytes(), "tariffClassGroupID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getTariffClassGroupID).array())
      }
      if (facts.getBundleGroupID != 0) {
        put.addImmutable("bundle".getBytes(), "bundleGroupID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getBundleGroupID).array())
      }


      // [bundle_plan_package]

      if (facts.getPackageID != 0) {
        put.addImmutable("bundle".getBytes(), "packageID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getPackageID).array()) //integer
      }
      if (facts.getPackageBalance != 0.0) {
        put.addImmutable("bundle".getBytes(), "packageBalance".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getPackageBalance).array()) //double
      }


      // [mvno_bundle_plan]
      if (facts.getIccID != null) {
        put.addImmutable("bundle".getBytes(), "iccID".getBytes(), facts.getIccID.getBytes()) // String
      }
      if (facts.getMobileNo != null) {
        put.addImmutable("bundle".getBytes(), "mobileNo".getBytes(), facts.getMobileNo.getBytes())
      }
      if (facts.getJoinDate != null) {
        put.addImmutable("bundle".getBytes(), "joinDate".getBytes(), format.format(facts.getJoinDate).getBytes()) //date
      }
      if (facts.getStopDate != null) {
        put.addImmutable("bundle".getBytes(), "stopDate".getBytes(), format.format(facts.getStopDate).getBytes()) //date
      }
      if (facts.getLastUpdate != null) {
        put.addImmutable("bundle".getBytes(), "lastUpdate".getBytes(), format.format(facts.getLastUpdate).getBytes()) //date
      }
      if (facts.getPayMode != 0) {
        put.addImmutable("bundle".getBytes(), "payMode".getBytes(), ByteBuffer.allocate(4).putInt(facts.getPayMode).array()) //integer
      }
      if (facts.getStartDate != null) {
        put.addImmutable("bundle".getBytes(), "startDate".getBytes(), format.format(facts.getStartDate).getBytes()) //date
      }
      if (facts.getEndDate != null) {
        put.addImmutable("bundle".getBytes(), "endDate".getBytes(), format.format(facts.getEndDate).getBytes()) //date
      }
      if (facts.getMvbpStatus != 0) {
        put.addImmutable("bundle".getBytes(), "mvbpStatus".getBytes(), ByteBuffer.allocate(4).putInt(facts.getMvbpStatus).array()) //integer
      }
      if (facts.getPaymentFlag != 0) {
        put.addImmutable("bundle".getBytes(), "paymentFlag".getBytes(), ByteBuffer.allocate(4).putInt(facts.getPaymentFlag).array()) //integer
      }


      // [mvno_account]

      if (facts.getCustCode != null) {
        put.addImmutable("bundle".getBytes(), "custCode".getBytes(), facts.getCustCode.getBytes()) // String
      }
      if (facts.getBatchCode != 0) {
        put.addImmutable("bundle".getBytes(), "batchCode".getBytes(), ByteBuffer.allocate(4).putInt(facts.getBatchCode).array())
      }
      if (facts.getSerialCode != 0) {
        put.addImmutable("bundle".getBytes(), "serialCode".getBytes(), ByteBuffer.allocate(4).putInt(facts.getSerialCode).array())
      }
      if (facts.getRenewStartDate != null) {
        put.addImmutable("bundle".getBytes(), "renewStartDate".getBytes(), format.format(facts.getRenewStartDate).getBytes()) //date
      }
      if (facts.getRenewDuedate != null) {
        put.addImmutable("bundle".getBytes(), "renewDuedate".getBytes(), format.format(facts.getRenewDuedate).getBytes()) //date
      }


      // [account_package] accpkg

      if (facts.getAccPkgBalance != 0.0) {
        put.addImmutable("bundle".getBytes(), "accPkgBalance".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getAccPkgBalance).array()) //double
      }
      if (facts.getCurrCode != null) {
        put.addImmutable("bundle".getBytes(), "currCode".getBytes(), facts.getCurrCode.getBytes())
      }
      if (facts.getmCustCode != null) {
        put.addImmutable("bundle".getBytes(), "mCustCode".getBytes(), facts.getmCustCode.getBytes()) // String
      }
      if (facts.getmBatchCode != 0) {
        put.addImmutable("bundle".getBytes(), "mBatchCode".getBytes(), ByteBuffer.allocate(4).putInt(facts.getmBatchCode).array())
      }
      if (facts.getmSerialCode != 0) {
        put.addImmutable("bundle".getBytes(), "mSerialCode".getBytes(), ByteBuffer.allocate(4).putInt(facts.getmSerialCode).array())
      }
      if (facts.getPackageType != 0) {
        put.addImmutable("bundle".getBytes(), "packageType".getBytes(), ByteBuffer.allocate(4).putInt(facts.getPackageType).array())
      }
      if (facts.getAccPkgLastUpdate != null) {
        put.addImmutable("bundle".getBytes(), "accPkgLastUpdate".getBytes(), format.format(facts.getAccPkgLastUpdate).getBytes()) //date
      }


      // account

      if (facts.getAccTrffClass != null) {
        put.addImmutable("bundle".getBytes(), "accTrffClass".getBytes(), facts.getAccTrffClass.getBytes()) // String
      }
      if (facts.getAccBalance != 0.0) {
        put.addImmutable("bundle".getBytes(), "accBalance".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getAccBalance).array()) //double
      }
      if (facts.getTotalCons != 0.0) {
        put.addImmutable("bundle".getBytes(), "totalCons".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getTotalCons).array()) //double
      }
      if (facts.getMonthLim != 0.0) {
        put.addImmutable("bundle".getBytes(), "monthLim".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getMonthLim).array()) //double
      }
      if (facts.getTotalCost != 0.0) {
        put.addImmutable("bundle".getBytes(), "totalCost".getBytes(), ByteBuffer.allocate(8).putDouble(facts.getTotalCost).array()) //double
      }
      if (facts.getAccStatus != 0) {
        put.addImmutable("bundle".getBytes(), "accStatus".getBytes(), ByteBuffer.allocate(4).putInt(facts.getAccStatus).array()) //integer
      }


      // package
      if (facts.getPkgName != null) {
        put.addImmutable("bundle".getBytes(), "pkgName".getBytes(), facts.getPkgName.getBytes()) // String
      }
      if (facts.getPkgTariffClass != null) {
        put.addImmutable("bundle".getBytes(), "pkgTariffClass".getBytes(), facts.getPkgTariffClass.getBytes()) // String
      }
      if (facts.getPackageTypeID != 0) {
        put.addImmutable("bundle".getBytes(), "packageTypeID".getBytes(), ByteBuffer.allocate(4).putInt(facts.getPackageTypeID).array()) //integer
      }
      if (facts.getDuration != 0) {
        put.addImmutable("bundle".getBytes(), "duration".getBytes(), ByteBuffer.allocate(4).putInt(facts.getDuration).array()) //integer
      }
      if (facts.getUssdInfoText != null) {
        put.addImmutable("bundle".getBytes(), "ussdInfoText".getBytes(), facts.getUssdInfoText.getBytes())
      }
      if (facts.getFlagToBuyBundle != 0) {
        put.addImmutable("bundle".getBytes(), "flagToBuyBundle".getBytes(), ByteBuffer.allocate(4).putInt(facts.getFlagToBuyBundle).array()) //integer
      }


      // package_template

      if (facts.getDaysValid != 0) {
        put.addImmutable("bundle".getBytes(), "daysValid".getBytes(), ByteBuffer.allocate(4).putInt(facts.getDaysValid).array())
      }
      if (facts.getExpiredDate != null) {
        put.addImmutable("bundle".getBytes(), "expiredDate".getBytes(), format.format(facts.getExpiredDate).getBytes()) //date
      }
      if (facts.getExpdateMode != 0) {
        put.addImmutable("bundle".getBytes(), "expdateMode".getBytes(), ByteBuffer.allocate(4).putInt(facts.getExpdateMode).array())
      }


      // Sim

      if (facts.getSubscriberStatus != 0) {
        put.addImmutable("bundle".getBytes(), "subscriberStatus".getBytes(), ByteBuffer.allocate(4).putInt(facts.getSubscriberStatus).array())
      }
      if (facts.getFirstUpdate != null) {
        put.addImmutable("bundle".getBytes(), "firstUpdate".getBytes(), format.format(facts.getFirstUpdate).getBytes()) //date
      }
       put

  }

  def populateBundleCase(mobileNo:String,bundleEvent: BundleEvent):BundleCases = { //pass the event Domain object
  val bundleCases = new BundleCases()
    bundleCases.setEvent(bundleEvent)
    bundleCases.setMobileNo(mobileNo)
    val formatter = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss")
    GenericUtility.cleanly(DriverManager.getConnection(ConfigReader.getConfigValueAsString("app.hbase.phoenixurl")))(_.close){
      connection =>{

        val mvnoAccountStatement = connection.prepareStatement("select pk,\"custcode\",\"batchcode\",\"serialcode\",\"renew_startdate\",\"renew_duedate\" from \"mvnoaccount\" where \"mobileNo\" like ? ")
        mvnoAccountStatement.setString(1,"%"+mobileNo+"%")
        val rset = mvnoAccountStatement.executeQuery
        while (rset.next) {
          bundleCases.setIccID(rset.getString("pk"))
          bundleCases.setCustCode(rset.getString("custcode"))
          if(rset.getString("batchcode")!=null)
          bundleCases.setBatchCode(Integer.parseInt(rset.getString("batchcode")))
          if(rset.getString("serialcode")!=null)
          bundleCases.setSerialCode(Integer.parseInt(rset.getString("serialcode")))
          if(rset.getString("renew_startdate")!=null)
          bundleCases.setRenewStartDate(formatter.parse(rset.getString("renew_startdate")))//d
          if(rset.getString("renew_duedate")!=null)
          bundleCases.setRenewDuedate(formatter.parse(rset.getString("renew_duedate")))//d
        } //System.out.println(rset.getString("VAL"))
        //finalBundle.setAccBalance()
        mvnoAccountStatement.close()

        val simStatement = connection.prepareStatement("select \"SubscriberStatus\",\"FirstUpdate\" from \"sim\" where pk like ?")
        simStatement.setString(1,"%"+bundleCases.getIccID()+"%")
        val rsetSim = simStatement.executeQuery
        while (rsetSim.next) {
          if(rsetSim.getString("SubscriberStatus")!=null)
          bundleCases.setSubscriberStatus(Integer.parseInt(rsetSim.getString("SubscriberStatus")))
          if(rsetSim.getString("FirstUpdate")!=null)
          bundleCases.setFirstUpdate(formatter.parse(rsetSim.getString("FirstUpdate")))//d
        } //System.out.println(rset.getString("VAL"))
        //finalBundle.setAccBalance()
        simStatement.close()

        val accountStatement = connection.prepareStatement("select \"trffclass\",\"balance\",\"totalcons\",\"monthlim\",\"totalcost\",\"status\" from \"account\" where \"custcode\" like ? and    \"batchcode\" like ? and \"serialcode\" like ?")
        accountStatement.setString(1,"%"+bundleCases.getCustCode+"%")
        accountStatement.setString(2,"%"+bundleCases.getBatchCode+"%")
        accountStatement.setString(3,"%"+bundleCases.getSerialCode+"%")
        val rsetAccount = accountStatement.executeQuery
        while (rsetAccount.next) {
          bundleCases.setAccTrffClass(rsetAccount.getString("trffclass"))
          if(rsetAccount.getString("balance")!=null)
          bundleCases.setAccBalance(java.lang.Double.parseDouble(rsetAccount.getString("balance")))
          if(rsetAccount.getString("totalcons")!=null)
          bundleCases.setTotalCons(java.lang.Double.parseDouble(rsetAccount.getString("totalcons")))
          if(rsetAccount.getString("monthlim")!=null)
          bundleCases.setMonthLim(java.lang.Double.parseDouble(rsetAccount.getString("monthlim")))
          if(rsetAccount.getString("totalcost")!=null)
          bundleCases.setTotalCost(java.lang.Double.parseDouble(rsetAccount.getString("totalcost")))
          if(rsetAccount.getString("status")!=null)
          bundleCases.setAccStatus(Integer.parseInt(rsetAccount.getString("status")))
        } //System.out.println(rset.getString("VAL"))
        //finalBundle.setAccBalance()
        accountStatement.close()

        val subscriberStatement = connection.prepareStatement("select a.pk as subscribId,\"firstname\",\"lastname\",\"email\",\"activationdate\" from \"subscriber\" a join \"subscriberline\" b on a.pk=b.pk where \"custcode\" like ? and \"batchcode\" like ? and \"serialcode\" like ?")
        subscriberStatement.setString(1,"%"+bundleCases.getCustCode+"%")
        subscriberStatement.setString(2,"%"+bundleCases.getBatchCode+"%")
        subscriberStatement.setString(3,"%"+bundleCases.getSerialCode+"%")
        val rsetSubscriber = subscriberStatement.executeQuery
        while (rsetSubscriber.next) {
          if(rsetSubscriber.getString("subscribId")!=null)
          bundleCases.setSubscriberID(Integer.parseInt(rsetSubscriber.getString("subscribId")))
          bundleCases.setFirstName(rsetSubscriber.getString("firstname"))
          bundleCases.setLastName(rsetSubscriber.getString("lastname"))
          bundleCases.setEmail(rsetSubscriber.getString("email"))
          if(rsetSubscriber.getString("activationdate")!=null)
          bundleCases.setActivationDate(formatter.parse(rsetSubscriber.getString("activationdate")))//d
        } //System.out.println(rset.getString("VAL"))
        //finalBundle.setAccBalance()
        subscriberStatement.close()


        val bundleStatement = connection.prepareStatement("select a.\"bundleid\" as bundleid,\"sitecode\",\"name\",\"price\",\"currency\",a.\"status\" as status,a.\"renewal_mode\" as renewal_mode,a.\"renewal_delay\" as renewal_delay,\"mainbundle_groupid\",\"family_groupid\",\"tariffclass_groupid\",\"bundle_groupid\",\"joindate\",\"stopdate\",\"lastupdate\",\"paymode\",\"startdate\",\"enddate\",c.\"status\" as mvpStatus,c.\"payment_flag\" as paymentFlag,c.\"updateby\" as updateby from \"bundleplan\" a right join \"mvnobundleplan\" c on a.\"bundleid\"=c.\"bundleid\" where \"mobileno\" like ? or \"iccid\" like ?")
        bundleStatement.setString(1,"%"+mobileNo+"%")
        bundleStatement.setString(2,"%"+bundleCases.getIccID()+"%")
        val rsetBundle = bundleStatement.executeQuery
        val bundleList = new util.ArrayList[MvNoBundlePlan]()
        while (rsetBundle.next) {
         val bundlePlan = new  MvNoBundlePlan()
          if(rsetBundle.getString("joindate")!=null)
          bundlePlan.setJoinDate(formatter.parse(rsetBundle.getString("joindate")))//d
          if(rsetBundle.getString("enddate")!=null)
          bundlePlan.setEndDate(formatter.parse(rsetBundle.getString("enddate")))//d
          if(rsetBundle.getString("lastupdate")!=null)
          bundlePlan.setLastUpdate(formatter.parse(rsetBundle.getString("lastupdate")))//d
          if(rsetBundle.getString("mvpStatus")!=null)
          bundlePlan.setMvbpStatus(Integer.parseInt(rsetBundle.getString("mvpStatus")))
          if(rsetBundle.getString("paymentFlag")!=null)
          bundlePlan.setPaymentFlag(Integer.parseInt(rsetBundle.getString("paymentFlag")))
          if(rsetBundle.getString("paymode")!=null)
          bundlePlan.setPayMode(Integer.parseInt(rsetBundle.getString("paymode")))
          if(rsetBundle.getString("startdate")!=null)
          bundlePlan.setStartDate(formatter.parse(rsetBundle.getString("startdate")))//d
          if(rsetBundle.getString("stopdate")!=null)
          bundlePlan.setStopDate(formatter.parse(rsetBundle.getString("stopdate")))//d
          if(rsetBundle.getString("bundle_groupid")!=null)
          bundlePlan.setBundleGroupID(Integer.parseInt(rsetBundle.getString("bundle_groupid")))
          if(rsetBundle.getString("bundleid")!=null)
          bundlePlan.setBundleID(Integer.parseInt(rsetBundle.getString("bundleid")))
          bundlePlan.setBundleName(rsetBundle.getString("name"))
          bundlePlan.setCurrency(rsetBundle.getString("currency"))
          if(rsetBundle.getString("family_groupid")!=null)
          bundlePlan.setFamilyGroupID(Integer.parseInt(rsetBundle.getString("family_groupid")))
          if(rsetBundle.getString("mainbundle_groupid")!=null)
          bundlePlan.setMainBundleGroupID(Integer.parseInt(rsetBundle.getString("mainbundle_groupid")))
          if(rsetBundle.getString("price")!=null)
          bundlePlan.setPrice(java.lang.Double.parseDouble(rsetBundle.getString("price")))
          if(rsetBundle.getString("renewal_delay")!=null)
          bundlePlan.setRenewalDelay(Integer.parseInt(rsetBundle.getString("renewal_delay")))
          if(rsetBundle.getString("renewal_mode")!=null)
          bundlePlan.setRenewalMode(Integer.parseInt(rsetBundle.getString("renewal_mode")))
          bundlePlan.setSiteCode(rsetBundle.getString("sitecode"))
          if(rsetBundle.getString("status")!=null)
          bundlePlan.setStatus(Integer.parseInt(rsetBundle.getString("status")))
          if(rsetBundle.getString("tariffclass_groupid")!=null)
          bundlePlan.setTariffClassGroupID(Integer.parseInt(rsetBundle.getString("tariffclass_groupid")))
          bundlePlan.setUpdateBy(rsetBundle.getString("updateby"))
          bundleList.add(bundlePlan)
        } //System.out.println(rset.getString("VAL"))
        //finalBundle.setAccBalance()
        bundleCases.setBundles(bundleList)
        bundleStatement.close()


        val packageStatement = connection.prepareStatement("select \"balance\",\"lastupdate\",\"currcode\",\"expDate\",\"package_id\",\"packagetype\",\"tariffClass\" from \"accountpackage\" where \"mobileNo\" like ?")
        packageStatement.setString(1,"%"+mobileNo+"%")
        val rsetPackages = packageStatement.executeQuery
        val packages = new util.ArrayList[Package]()
        while (rsetPackages.next) {
          val mpackage = new Package()
          if(rsetPackages.getString("balance")!=null)
          mpackage.setAccPkgBalance(java.lang.Double.parseDouble(rsetPackages.getString("balance")))
          if(rsetPackages.getString("lastupdate")!=null)
          mpackage.setAccPkgLastUpdate(formatter.parse(rsetPackages.getString("lastupdate")))
          mpackage.setCurrCode(rsetPackages.getString("currcode"))
          if(rsetPackages.getString("expDate")!=null)
          mpackage.setExpiredDate(formatter.parse(rsetPackages.getString("expDate")))//d
          if(rsetPackages.getString("package_id")!=null)
          mpackage.setPackageID(Integer.parseInt(rsetPackages.getString("package_id")))
          if(rsetPackages.getString("packagetype")!=null)
          mpackage.setPackageType(Integer.parseInt(rsetPackages.getString("packagetype")))
          mpackage.setPkgTariffClass(rsetPackages.getString("tariffClass"))
          packages.add(mpackage)

        } //System.out.println(rset.getString("VAL"))
        //finalBundle.setAccBalance()
        bundleCases.setPackages(packages)
        packageStatement.close()


        val topupLogStatement = connection.prepareStatement("select \"afterbal\",\"prevbal\",\"currcode\",\"tp_tariffclass\",\"paymentType\",\"createdate\",\"transstatusID\",\"currcode\"  from \"topuplog\" where \"mobileno\" like ?")
        val dateOld = Calendar.getInstance()
        dateOld.add(Calendar.MONTH,-1)
        //topupLogStatement.setDate(1,(new java.sql.Date(dateOld.getTimeInMillis)))
        //topupLogStatement.setDate(2,new java.sql.Date(new Date().getTime))
        topupLogStatement.setString(1,"%"+mobileNo+"%")
        val rsetTopUp = topupLogStatement.executeQuery
        val topupLogList = new util.ArrayList[TopupLog]()
        while (rsetTopUp.next) {
          val topupLog = new TopupLog()
          if(rsetTopUp.getString("afterbal")!=null)
          topupLog.setAfterbal(java.lang.Float.parseFloat(rsetTopUp.getString("afterbal")))
          if(rsetTopUp.getString("createdate")!=null)
          topupLog.setCreatedate(formatter.parse(rsetTopUp.getString("createdate")))
          topupLog.setCurrcode(rsetTopUp.getString("currcode"))
          if(rsetTopUp.getString("paymentType")!=null)
          topupLog.setPaymentType(Integer.parseInt(rsetTopUp.getString("paymentType")))
          if(rsetTopUp.getString("prevbal")!=null)
          topupLog.setPrevbal(java.lang.Float.parseFloat(rsetTopUp.getString("prevbal")))
          topupLog.setTpTariffclass(rsetTopUp.getString("tp_tariffclass"))
          if(rsetTopUp.getString("transstatusID")!=null)
          topupLog.setTransstatusID(Integer.parseInt(rsetTopUp.getString("transstatusID")))
          topupLogList.add(topupLog)
        }
        bundleCases.setLogs(topupLogList)
        //System.out.println(rset.getString("VAL"))
        //finalBundle.setAccBalance()
        topupLogStatement.close()

        val bundleLogStatement = connection.prepareStatement("select distinct \"logdate\",\"processname\",a.\"bundleid\" as bundleid,b.\"status\" as status,a.\"mobileno\" as mobileNo,\"startdate\",\"enddate\",\"updateby\",\"renewal_mode\" from \"mvnobundleplan\" a right join \"bundlelog\" b on a.\"mobileno\"=b.\"mobileno\" and a.\"bundleid\"=b.\"bundleid\" where a.\"status\" like ? and b.\"status\" like ? and a.\"mobileno\" like ?")

        //topupLogStatement.setDate(1,(new java.sql.Date(dateOld.getTimeInMillis)))
        //topupLogStatement.setDate(2,new java.sql.Date(new Date().getTime))
        bundleLogStatement.setString(1,"%"+1+"%")
        bundleLogStatement.setString(2,"%"+0+"%")
        bundleLogStatement.setString(3,"%"+mobileNo+"%")
        val rsetbundleLog = bundleLogStatement.executeQuery
        val bundleLogList = new util.ArrayList[BundleLog]()
        while (rsetbundleLog.next) {
          val bundleLog = new BundleLog()
          if(rsetbundleLog.getString("logdate")!=null)
            bundleLog.setLogDate(formatter.parse(rsetbundleLog.getString("logdate")))
          if(rsetbundleLog.getString("processname")!=null)
            bundleLog.setProcessName(rsetbundleLog.getString("processname"))
          if(rsetbundleLog.getString("bundleid")!=null)
            bundleLog.setBundleID(Integer.parseInt(rsetbundleLog.getString("bundleid")))
          if(rsetbundleLog.getString("status")!=null)
            bundleLog.setBundleLogstatus(Integer.parseInt(rsetbundleLog.getString("status")))
          if(rsetbundleLog.getString("mobileNo")!=null)
            bundleLog.setMobileNo(rsetbundleLog.getString("mobileNo"))
          if(rsetbundleLog.getString("startdate")!=null)
            bundleLog.setStartDate(formatter.parse(rsetbundleLog.getString("startdate")))
          if(rsetbundleLog.getString("enddate")!=null)
            bundleLog.setEndDate(formatter.parse(rsetbundleLog.getString("enddate")))

          bundleLogList.add(bundleLog)
        }
        bundleCases.setBundlelogs(bundleLogList)

        bundleLogStatement.close()

        bundleCases
      }
    }match {
      case Left(exception) => {
        exception.printStackTrace()
        return bundleCases
      }
      case Right(b) => return b
    }
  }



}
