package com.mundio.mat

import com.google.gson.GsonBuilder
import com.mundio.rules.BundleEvent
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.hadoop.hbase.TableName

import scalaj.http._

/**
  * Created by sinchan on 12-02-2017.
  */
object Driver extends App {

  val spark = SparkSession.builder()
    .appName(ConfigReader.getConfigValueAsString("app.name"))
    .getOrCreate()

  val ssc = new StreamingContext(spark.sparkContext, Seconds(60))

  val config = HBaseConfiguration.create()
  //config.set("hbase.zookeeper.quorum", "127.0.0.1")

  HBaseAdmin.checkHBaseAvailable(config)
  config.set(TableOutputFormat.OUTPUT_TABLE, "eventfact")
  config.set("mapreduce.outputformat.class", "org.apache.hadoop.hbase.mapreduce.TableOutputFormat")


  val kafkaParams = Map[String, Object](
    "bootstrap.servers" -> ConfigReader.getConfigValueAsString("app.kafka.event.broker"),
    "key.deserializer" -> classOf[StringDeserializer],
    "value.deserializer" -> classOf[StringDeserializer],
    "group.id" -> "1",
    "auto.offset.reset" -> "latest",
    "enable.auto.commit" -> (false: java.lang.Boolean)
  )

  val stream = KafkaUtils.createDirectStream[String, String](
    ssc,
    PreferConsistent,
    Subscribe[String, String](Array(ConfigReader.getConfigValueAsString("app.kafka.event.topic")), kafkaParams)
  )
  var currentKey = ""
  val processedStream = stream.map(record =>{
    currentKey = record.key
    (record.key, record.value)})


  processedStream.foreachRDD(message => message.foreach(pair => {
    //try {
    val key = pair._1
    val value = pair._2

    val config = HBaseConfiguration.create()
    //config.set("hbase.zookeeper.quorum", "127.0.0.1")

    HBaseAdmin.checkHBaseAvailable(config)
    config.set(TableOutputFormat.OUTPUT_TABLE, "eventfact")
    config.set("mapreduce.outputformat.class", "org.apache.hadoop.hbase.mapreduce.TableOutputFormat")

    //var connection
    /** A lightweight handle to a specific table. Used from a single thread. */
    //var table
    GenericUtility.cleanly(ConnectionFactory.createConnection(config))(_.close) { connection => {
      GenericUtility.cleanly(connection.getTable(TableName.valueOf(Bytes.toBytes("eventfact"))))(_.close) { table => {
        val hbasePuts = if (key.contains("customer") && key.contains("bundle")) HBaseUtility.populateBundlePuts(key, value) else HBaseUtility.populatePuts(key, value)
        table.put(hbasePuts)
      }
      }
    }
    }


    implicit val formats = org.json4s.DefaultFormats
    val gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create()
    val event = gson.fromJson(value, classOf[BundleEvent])
    val bundlePojo = HBaseUtility.populateBundleCase(event.getMobileNo, event)
    //val properties = parse(value).extract[Map[String, Any]]
    //val factInstance = if (key.contains("customer")) gson.fromJson(value, classOf[CustomerFact]) else new Gson().fromJson(value, classOf[Facts])
    val urlString = if (key.contains("customer") && key.contains("bundle")) ConfigReader.getConfigValueAsString("app.drools.custbundle") else ConfigReader.getConfigValueAsString("app.drools.resturl")
    val response = Http(urlString).timeout(Integer.MAX_VALUE, Integer.MAX_VALUE).postData(gson.toJson(bundlePojo)).header("content-type", "application/json").asString
    //"{ \"sendsms\":" + checkNulltoDefault(evaluatedFacts.getSendsms)+ ", \"blockcall\"" +checkNulltoDefault(evaluatedFacts.getBlockcall)+",\"blocknumber\":" +checkNulltoDefault(evaluatedFacts.getBlocknumber)+",\"sendpush\":" +checkNulltoDefault(evaluatedFacts.getSendpush)+",\"sendmail\":" +checkNulltoDefault(evaluatedFacts.getSendmail)+"}"
    val resultMessage = response.body

    val notificationTopic = ConfigReader.getConfigValueAsString("app.kafka.notification.topic." + key)
    val notificationBroker = ConfigReader.getConfigValueAsString("app.kafka.notification.broker")


    KafkaUtility.produceMesssage(notificationTopic, notificationBroker, key, resultMessage)
  /*}catch
  {
    case ex:Exception => println("error occurred in processing the message with error: " + ex)
  }*/
  }))
  ssc.start()
  ssc.awaitTermination()


}
