package com.mundio.rules;

import java.io.Serializable;

/**
 * Created by sinchan on 05/04/17.
 */
public class Facts implements Serializable {

    private String app ;
    private Double version ;
    private Boolean trynow ;
    private String sendsms;
    private String blockcall;
    private String blocknumber;//: String
    private String sendpush;// String
    private String sendmail;// String

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public Double getVersion() {
        return version;
    }

    public void setVersion(Double version) {
        this.version = version;
    }

    public Boolean getTrynow() {
        return trynow;
    }

    public void setTrynow(Boolean trynow) {
        this.trynow = trynow;
    }

    public String getSendsms() {
        return sendsms;
    }

    public void setSendsms(String sendsms) {
        this.sendsms = sendsms;
    }

    public String getBlockcall() {
        return blockcall;
    }

    public void setBlockcall(String blockcall) {
        this.blockcall = blockcall;
    }

    public String getBlocknumber() {
        return blocknumber;
    }

    public void setBlocknumber(String blocknumber) {
        this.blocknumber = blocknumber;
    }

    public String getSendpush() {
        return sendpush;
    }

    public void setSendpush(String sendpush) {
        this.sendpush = sendpush;
    }

    public String getSendmail() {
        return sendmail;
    }

    public void setSendmail(String sendmail) {
        this.sendmail = sendmail;
    }
}
