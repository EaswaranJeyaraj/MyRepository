package com.mundio.rules;

import java.util.Date;

/**
 * Created by hadoop on 6/27/17.
 */
public class BundleLog {

    private int packageID;
    private Date logDate;
    private int bundleID;
    private Date startDate;
    private Date endDate;
    private String processName;
    private int bundleLogstatus;
    private String mobileNo;

    public int getPackageID() {
        return packageID;
    }

    public void setPackageID(int packageID) {
        this.packageID = packageID;
    }

    public Date getLogDate() {
        return logDate;
    }

    public void setLogDate(Date logDate) {
        this.logDate = logDate;
    }

    public int getBundleID() {
        return bundleID;
    }

    public void setBundleID(int bundleID) {
        this.bundleID = bundleID;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public int getBundleLogstatus() {
        return bundleLogstatus;
    }

    public void setBundleLogstatus(int bundleLogstatus) {
        this.bundleLogstatus = bundleLogstatus;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }


}
