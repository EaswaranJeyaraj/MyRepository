--20/JULY/2016

--SQL SERVER SCRIPTS

-- CDR DATA -----

select * into hdp.dbo.cdr_2015_H from cdr.dbo.xcdr_fr_012015

alter table hdp.dbo.cdr_2015_H add idc int identity (1,1)

insert into hdp.dbo.cdr_2015_H select * from cdr.dbo.xcdr_fr_122015

select count(*) from hdp.dbo.cdr_2015_H	---9810917 -----

alter table hdp.dbo.cdr_2015_H add did_30 int
alter table hdp.dbo.cdr_2015_H add talk_70 int
alter table hdp.dbo.cdr_2015_H add talk_100 int
alter table hdp.dbo.cdr_2015_H add talk_200 int

select top 345 * from hdp.dbo.cdr_2015_H

update hdp.dbo.cdr_2015_H set did_30=3
update hdp.dbo.cdr_2015_H set talk_70=7
update hdp.dbo.cdr_2015_H set talk_100=10
update hdp.dbo.cdr_2015_H set talk_200=20


--GMS INCOMING DATA ---2015 ---

SELECT * into hdp.dbo.gms_2015_H from dbo.xgms_fr_012015

alter table hdp.dbo.gms_2015_H add idg int identity(1,1)

insert into hdp.dbo.gms_2015_H select * from dbo.xgms_fr_122015

select count(*) from hdp.dbo.gms_2015_H   --- 13760920 ---

SELECT top 365 * from hdp.dbo.gms_2015_H



---------------------------------------------------------------

--NETWORK OPERATOR


select  * from  account_name --Trunk 


select top 10  * from mrec_201605 --OprMask_B



select distinct cli,Domain_A,operator_a,cli,did,dialednum,destcode,domain_b,OprMask_B,operator_b,b.trunk,b.name,b.manager_name from mrec_201605 a 
join account_name b on a.OprMask_B=b.trunk



--MREC DATA 2015 ----


select * into hdp.dbo.mrec_2015_H from mrec201501 where domain_a='mfr'

alter table hdp.dbo.mrec_2015_H add idm int identity (1,1)

insert into hdp.dbo.mrec_2015_H select * from mrec201512  where domain_a='mfr'

select count(*) from hdp.dbo.mrec_2015_H  -- 9819348


---------------------------------------------------------------------------------------------

--70 MINUTES REPORT CDR,INCOMING,FIRSTUPDATE,BUNDLE,VOUCHER TARIFFCLASS,HISTORY
--------------------------------------------------------------------------------


--CALLS GREATER THAN 70 MINUTES

select distinct ani,convert(varchar(10),calldate,121) calldate,custcode CustomerCode,
destcode DestinationCode,did DestinationNo,count(*) NoofCalls,sum(talktime)/60. talktime,datepart(hh,calldate) hour,
datepart(mm,calldate) minutes,
trffclass,sitecode --into hdp.dbo.new_70_cdr
from hdp.dbo.cdr_2015_H 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
--and datepart(hh,calldate) between 0 and 12
--and convert(varchar(10),calldate,121)='01-01-2015'
group by ani,convert(varchar(10),calldate,121),datepart(hh,calldate),datepart(mm,calldate),custcode,destcode,trffclass,sitecode,did
having sum(talktime)/60.>=0
order by convert(varchar(10),calldate,121),datepart(hh,calldate)
--convert(varchar(10),calldate,121)   -- 3424 

select * from hdp.dbo.new_200_cdr

select distinct ani from hdp.dbo.new_200_cdr  -- 511 Records
DROP TABLE hdp.dbo.new_200_cdr