
--47.Fraud Report - High Number of calls (30 distinct mobile number)

select distinct cli,cmdate,custcode,
destcode DestinationCode,count(distinct(did)) countofdid,destcode DestinationName,
count(*) NoofMOCalls,sum(talktime_inmin)MO_talktime,
datepart(hh,calldate) hrs,
datepart(mi,calldate) mins,mm,
TariffClass,trffname,domain_a,oprmask_b
--into hdp.dbo.fr_did_2015
from hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR' and cli like '33%'
group by cli,custcode,domain_a,TariffClass,trffname,destcode,mm,
datepart(hh,calldate),datepart(mi,calldate),oprmask_b,cmdate
having count(distinct(did))>=0
order by cmdate -- 5322279 Records

select * from hdp.dbo.fr_did_2015 where countofdid>=3
select count(*) from hdp.dbo.fr_did_2015
drop table hdp.dbo.fr_did_2015

--FIRST UPDATE

alter table hdp.dbo.fr_did_2015 add firstupdate datetime



select mobileNo,a.iccid,convert(varchar(10),FirstUpdate,121) firstupdate into hdp.dbo.fr_did_2015_fstupdate 
FROM [CDR].[dbo].[mvno_account_H] a join [esp_mfr].[dbo].[SIM] b on
a.iccid=b.ICCID and mobileNo in(select  distinct cli from hdp.dbo.fr_did_2015) 
order by convert(varchar(10),FirstUpdate,121)  --97775 Records


--Updating FirstUpdate to Main Report Table

update b set b.firstupdate=a.FirstUpdate from hdp.dbo.fr_did_2015_fstupdate  a
right join hdp.dbo.fr_did_2015 b on a.mobileno=b.cli -- 5332447  Records


--INCOMING MINUTES


select msisdn,convert(varchar(10),calldate,121)calldate,sum(legadur)/60. mt_talktime,
count(*) countofincomingmin --into hdp.dbo.fr_did_2015_incoming 
from [HDP].dbo.gms_2015_H
where msisdn  in (select distinct cli from hdp.dbo.fr_did_2015)
group by msisdn,convert(varchar(10),calldate,121)
order by calldate -- 2240004

select top 43 * from hdp.dbo.fr_did_2015_incoming order by calldate   -- 2240004

alter table hdp.dbo.fr_did_2015 add MT_talktime int
alter table hdp.dbo.fr_did_2015 add MT_incmin_count int
alter table hdp.dbo.fr_did_2015 drop column incoming_min 


--Updating Incoming MinutesRecords

update b set b.MT_talktime=a.mt_talktime,b.MT_incmin_count=a.countofincomingmin 
from hdp.dbo.fr_did_2015_incoming a right join
hdp.dbo.fr_did_2015 b on b.cli=a.msisdn 
and convert(varchar(10),a.calldate,121)=cmdate -- 

select top 4 * from hdp.dbo.fr_did_2015 where bundlename is not null



--UPDATING BUNDLE RELATED DETAILS

select a.mobileno,iccid,a.bundleid,name bundlename,a.status,description,convert(varchar(10),startdate,121) startdate,
convert(varchar(10),enddate,121) enddate
into hdp.dbo.fr_did_2015_bundle --Creating Temp Table for Bundle Info
from esp_mfr.dbo.mvno_bundle_plan a
join esp_mfr.dbo.bundle_plan b on a.bundleid=b.bundleid where a.status=1 
and a.mobileno in(select  distinct cli from hdp.dbo.fr_did_2015)  -- 387 Records

--TEMP TABLE FOR BUNDLE INFO
select * from hdp.dbo.fr_did_2015 -- 387 Records


alter table hdp.dbo.fr_did_2015 add bundlename varchar(50)
alter table hdp.dbo.fr_did_2015 add bstatus char(5)
alter table hdp.dbo.fr_did_2015 add bstartdate datetime
alter table hdp.dbo.fr_did_2015 add benddate datetime
alter table hdp.dbo.fr_did_2015 add bdescription varchar(50)

SELECT * FROM hdp.dbo.fr_callscdr2015 where bundlename is not null

update b set b.bundlename=a.bundlename,b.bstatus=a.status,b.bstartdate=a.startdate,
b.benddate=a.enddate,b.bdescription=a.description from hdp.dbo.fr_did_2015_bundle a 
right join hdp.dbo.fr_did_2015 b
on a.mobileno=b.cli  -- 






--TOPUP

select count(*) NoOfTopups,b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,
convert(varchar(10),createdate,121) as topupdate,amount/100 amount,tp_tariffclass,calledby topuptype,
resellerid,fullname resellername,address reseller_address into hdp.dbo.fr_did_2015_tp_count -- Temp Table for Topup Details 4903
from esp_mfr.dbo.mvno_account b(nolock) join esp_mfr.dbo.topup_log a
on a.custcode=b.custcode and a.batchcode=b.batchcode and a.serialcode=b.serialcode
and a.mobileno=b.mobileno join esp_mfr.dbo.activation d      
on b.custcode=d.custcode and b.batchcode=d.batchcode and b.serialcode between d.serialcode_fr and d.serialcode_to      
inner join esp_mfr.dbo.reseller e(nolock) on d.sellerid=e.resellerid
where b.mobileno in(select  distinct cli from hdp.dbo.fr_did_2015)
and transstatusid=1 and b.mobileno is not null 
group by b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,convert(varchar(10),createdate,121),amount,tp_tariffclass,calledby,
resellerid,fullname,address 
order by   b.mobileno,convert(varchar(10),createdate,121) -- 925340 Records



select * from  hdp.dbo.cgrt_2015_tp_count--925340



--TOPUP MODE

select V_Tarcls_id,[V_Trff_CardName],[V_Tariffcls],[Denomination_id],b.V_Type_Id,[V_type] into hdp.dbo.tmp_topup_mode 
  from [Master_Mundio].[dbo].[Vouchers_TariffCls] a
  join [Master_Mundio].[dbo].[Voucher_types] b on a.V_Type_Id=b.V_Type_Id
  
  --Final Topup
  
  select distinct mobileno,NoOfTopups,topupdate,amount tp_amount,tp_tariffclass,topuptype,resellerid,resellername,reseller_address,V_Trff_CardName Tariff,
  V_type into hdp.dbo.fr_did_2015_topup_final 
  from hdp.dbo.fr_did_2015_tp_count a join [HDP].[dbo].[tmp_topup_mode] b
  on a.tp_tariffclass=b.V_Tariffcls  order by topupdate -- 924705
  
  
  drop table hdp.dbo.fr_did_2015_topup_final


alter table hdp.dbo.cgrt_2015_topup_final drop column mode





--Altering Main Report Table (HDP.dbo.final_report) to accommodate the topup details

alter table hdp.dbo.fr_did_2015 add topupdate datetime
alter table hdp.dbo.fr_did_2015 add amount float
alter table hdp.dbo.fr_did_2015 add tp_trffcls varchar(4)
alter table hdp.dbo.fr_did_2015 add topupmode varchar(100)
alter table hdp.dbo.fr_did_2015 add tariff varchar(200)
alter table hdp.dbo.fr_did_2015 add topuptype varchar(15)
alter table hdp.dbo.fr_did_2015 add resellerid int
alter table hdp.dbo.fr_did_2015 add resellername varchar(512)
alter table hdp.dbo.fr_did_2015 add rsladdress varchar(256)



--Updating Topup and Mode of Payment and Reseller Shopname Detail to Main Report Table
  
		--Updating HDP.dbo.final_report
  
  update b set b.topupdate=a.topupdate,b.tariff=a.Tariff,b.topuptype=a.topuptype,
b.amount=a.tp_amount,b.tp_trffcls=a.tp_tariffclass,b.topupmode=a.V_type,
b.resellerid=a.resellerid,b.resellername=a.resellername,b.rsladdress=a.reseller_address
from hdp.dbo.fr_did_2015_topup_final a right join hdp.dbo.fr_did_2015 b on  
b.cli=a.mobileno    -- 5322279

select  * from hdp.dbo.fr_did_2015_topup_final  -- 

SELECT top 1100 *  FROM hdp.dbo.fr_did_2015


--NETWORK OPERATOR

select distinct cli,b.name,b.manager_name --into #test 
from hdp.dbo.fr_did_2015 a 
join cdr.dbo.account_name b on a.OprMask_B=b.trunk 
where cli is not null  ---  Records

alter table hdp.dbo.fr_did_2015 add network varchar(50)
alter table hdp.dbo.fr_did_2015 add mngrname varchar(50)

update b set b.network=a.name,b.mngrname=a.manager_name from cdr.dbo.account_name a
right join hdp.dbo.fr_did_2015 b on b.OprMask_B=a.trunk   -- 5322279

select * from hdp.dbo.fr_did_2015 
where network is not null order by countofdid desc


select * from hdp.dbo.fr_did_2015 where countofdid>=4




