--20/JULY/2016

--SQL SERVER SCRIPTS

-- CDR DATA -----

select * into hdp.dbo.cdr_2015_H from cdr.dbo.xcdr_fr_012015

alter table hdp.dbo.cdr_2015_H add idc int identity (1,1)

insert into hdp.dbo.cdr_2015_H select * from cdr.dbo.xcdr_fr_122015

select count(*) from hdp.dbo.cdr_2015_H	---9810917 -----

alter table hdp.dbo.cdr_2015_H add did_30 int
alter table hdp.dbo.cdr_2015_H add talk_70 int
alter table hdp.dbo.cdr_2015_H add talk_100 int
alter table hdp.dbo.cdr_2015_H add talk_200 int

select top 345 * from hdp.dbo.cdr_2015_H

update hdp.dbo.cdr_2015_H set did_30=3
update hdp.dbo.cdr_2015_H set talk_70=7
update hdp.dbo.cdr_2015_H set talk_100=10
update hdp.dbo.cdr_2015_H set talk_200=20


--GMS INCOMING DATA ---2015 ---

SELECT * into hdp.dbo.gms_2015_H from cdr.dbo.xgms_fr_012015

alter table hdp.dbo.gms_2015_H add idg int identity(1,1)

insert into hdp.dbo.gms_2015_H select * from CDR.dbo.xgms_fr_122015

select count(*) from hdp.dbo.gms_2015_H   --- 13760920 ---

SELECT top 365 * from hdp.dbo.gms_2015_H



---------------------------------------------------------------

--NETWORK OPERATOR


select  * from  account_name --Trunk 


select top 10  * from mrec_201605 --OprMask_B



select distinct cli,Domain_A,operator_a,cli,did,dialednum,destcode,domain_b,OprMask_B,operator_b,b.trunk,b.name,b.manager_name from mrec_201605 a 
join account_name b on a.OprMask_B=b.trunk



--MREC DATA 2015 ----


select * into hdp.dbo.mrec_2015_H from mrec201501 where domain_a='mfr'

alter table hdp.dbo.mrec_2015_H add idm int identity (1,1)

insert into hdp.dbo.mrec_2015_H select * from mrec201512  where domain_a='mfr'

select count(*) from hdp.dbo.mrec_2015_H  -- 9819348
drop table hdp.dbo.fr_smscdr2015

---------------------------------------------------------------------------------------------

--100 MINUTES REPORT CDR,INCOMING,FIRSTUPDATE,BUNDLE,VOUCHER TARIFFCLASS,HISTORY
--------------------------------------------------------------------------------


--CALLS GREATER THAN 100 MINUTES

select distinct cli,cmdate,convert(varchar(10),calldate,121)calldate,
destcode DestinationCode,did DestinationNo,destcode DestinationName,
count(*) NoofCalls,sum(talktime_inmin)MO_talktime,
datepart(hh,calldate) hour,
datepart(mi,calldate) minutes,oprmask_b,
TariffClass,trffname,domain_a 
into hdp.dbo.fr_callscdr2015
from hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR'
group by cli,convert(varchar(10),calldate,121),custcode,domain_a,TariffClass,trffname,destcode,did,
datepart(hh,calldate),datepart(mi,calldate),oprmask_b,cmdate
having sum(talktime_inmin)>=0
order by cmdate -- 5332447

select * from hdp.dbo.fr_callscdr2015   where trffname is not null and noofcalls>1 order by cmdate -- 5332447

select distinct calldate from hdp.dbo.new_70_cdr  -- 1381

select top 4 * from hdp.dbo.mrec_2015_hp

drop table hdp.dbo.cgrt_2015_firstupdate


--FIRST UPDATE

alter table hdp.dbo.fr_callscdr2015 add firstupdate datetime



select mobileNo,a.iccid,convert(varchar(10),FirstUpdate,121) firstupdate into hdp.dbo.cgrt_2015_firstupdate 
FROM [CDR].[dbo].[mvno_account_H] a join [esp_mfr].[dbo].[SIM] b on
a.iccid=b.ICCID and mobileNo in(select  distinct cli from hdp.dbo.fr_callscdr2015) 
order by convert(varchar(10),FirstUpdate,121)  --97775 Records


--Updating FirstUpdate to Main Report Table

update b set b.firstupdate=a.FirstUpdate from hdp.dbo.cgrt_2015_firstupdate  a
join hdp.dbo.fr_callscdr2015 b on a.mobileno=b.cli -- 5288286  Records



--INCOMING MINUTES


select msisdn,convert(varchar(10),calldate,121)calldate,sum(legadur)/60. mt_talktime,
count(*) countofincomingmin into hdp.dbo.cgrt_2015_incoming 
from [HDP].dbo.gms_2015_H
where msisdn  in (select distinct cli from hdp.dbo.fr_callscdr2015)
group by msisdn,convert(varchar(10),calldate,121)
order by calldate

select top 43 * from hdp.dbo.cgrt_2015_incoming order by calldate   -- 2240004

alter table hdp.dbo.fr_callscdr2015 add MT_talktime int
alter table hdp.dbo.fr_callscdr2015 add MT_incomingmin_count int
alter table hdp.dbo.fr_callscdr2015 drop column incoming_min 


--Updating Incoming MinutesRecords

update b set b.MT_talktime=a.mt_talktime,b.MT_incomingmin_count=a.countofincomingmin from hdp.dbo.cgrt_2015_incoming a join
hdp.dbo.fr_callscdr2015 b on b.cli=a.msisdn 
and convert(varchar(10),a.calldate,121)=convert(varchar(10),b.calldate,121) -- 3520724

select top 4 * from hdp.dbo.fr_callscdr2015


--UPDATING BUNDLE RELATED DETAILS

select a.mobileno,iccid,a.bundleid,name bundlename,a.status,description,convert(varchar(10),startdate,121) startdate,
convert(varchar(10),z,121) enddate
into hdp.dbo.cgrt_2015_callbundle --Creating Temp Table for Bundle Info
from esp_mfr.dbo.mvno_bundle_plan a
join esp_mfr.dbo.bundle_plan b on a.bundleid=b.bundleid where a.status=1 
and a.mobileno in(select  distinct cli from hdp.dbo.fr_callscdr2015)  -- 387 Records

--TEMP TABLE FOR BUNDLE INFO
select * from hdp.dbo.cgrt_2015_callbundle -- 387 Records
select *from esp_mfr.dbo.bundle_plan
select *from esp_mfr.dbo.mvno_bundle_plan

select *from esp_mfr.dbo.bundle_plan_Package a
join
esp_mfr.dbo.packages b on packageid = b.package_id
select *from esp_mfr.dbo.packages
alter table hdp.dbo.fr_callscdr2015 add bundlename varchar(50)
alter table hdp.dbo.fr_callscdr2015 add bstatus char(5)
alter table hdp.dbo.fr_callscdr2015 add bstartdate datetime
alter table hdp.dbo.fr_callscdr2015 add benddate datetime
alter table hdp.dbo.fr_callscdr2015 add bdescription varchar(50)

SELECT * FROM hdp.dbo.fr_callscdr2015 where bundlename is not null

update b set b.bundlename=a.bundlename,b.bstatus=a.status,b.bstartdate=a.startdate,
b.benddate=a.enddate,b.bdescription=a.description from hdp.dbo.cgrt_2015_callbundle a 
right join hdp.dbo.fr_callscdr2015 b
on a.mobileno=b.cli -- 5332447 Records


--TOPUP

select count(*) NoOfTopups,b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,
convert(varchar(10),createdate,121) as topupdate,amount/100 amount,tp_tariffclass,calledby topuptype,
resellerid,fullname resellername,address reseller_address into hdp.dbo.cgrt_2015_tp_count -- Temp Table for Topup Details 4903
from esp_mfr.dbo.mvno_account b(nolock) join esp_mfr.dbo.topup_log a
on a.custcode=b.custcode and a.batchcode=b.batchcode and a.serialcode=b.serialcode
and a.mobileno=b.mobileno join esp_mfr.dbo.activation d      
on b.custcode=d.custcode and b.batchcode=d.batchcode and b.serialcode between d.serialcode_fr and d.serialcode_to      
inner join esp_mfr.dbo.reseller e(nolock) on d.sellerid=e.resellerid
where b.mobileno in(select  distinct cli from hdp.dbo.fr_callscdr2015)
and transstatusid=1 and b.mobileno is not null 
group by b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,convert(varchar(10),createdate,121),amount,tp_tariffclass,calledby,
resellerid,fullname,address 
order by   b.mobileno,convert(varchar(10),createdate,121)



select * from  hdp.dbo.cgrt_2015_tp_count--925340



--TOPUP MODE

select V_Tarcls_id,[V_Trff_CardName],[V_Tariffcls],[Denomination_id],b.V_Type_Id,[V_type] into hdp.dbo.tmp_topup_mode 
  from [Master_Mundio].[dbo].[Vouchers_TariffCls] a
  join [Master_Mundio].[dbo].[Voucher_types] b on a.V_Type_Id=b.V_Type_Id
  
  --Final Topup
  
  select distinct mobileno,NoOfTopups,topupdate,amount tp_amount,tp_tariffclass,topuptype,resellerid,resellername,reseller_address,V_Trff_CardName Tariff,
  V_type into hdp.dbo.cgrt_2015_topup_final 
  from hdp.dbo.cgrt_2015_tp_count a join [HDP].[dbo].[tmp_topup_mode] b
  on a.tp_tariffclass=b.V_Tariffcls  order by topupdate -- 924705
  
  select * from hdp.dbo.cgrt_2015_topup_final 
  select count(*) from hdp.dbo.cgrt_2015_topup_final 
  
  drop table hdp.dbo.new_70_topup_final
  


alter table hdp.dbo.cgrt_2015_topup_final drop column mode





--Altering Main Report Table (HDP.dbo.final_report) to accommodate the topup details

alter table hdp.dbo.fr_callscdr2015 add topupdate datetime
alter table hdp.dbo.fr_callscdr2015 add amount float
alter table hdp.dbo.fr_callscdr2015 add tp_trffcls varchar(4)
alter table hdp.dbo.fr_callscdr2015 add topupmode varchar(100)
alter table hdp.dbo.fr_callscdr2015 add tariff varchar(200)
alter table hdp.dbo.fr_callscdr2015 add topuptype varchar(15)
alter table hdp.dbo.fr_callscdr2015 add resellerid int
alter table hdp.dbo.fr_callscdr2015 add resellername varchar(512)
alter table hdp.dbo.fr_callscdr2015 add rsladdress varchar(256)



--Updating Topup and Mode of Payment and Reseller Shopname Detail to Main Report Table
  
		--Updating HDP.dbo.final_report
  
  update b set b.topupdate=a.topupdate,b.tariff=a.Tariff,b.topuptype=a.topuptype,
b.amount=a.tp_amount,b.tp_trffcls=a.tp_tariffclass,b.topupmode=a.V_type,
b.resellerid=a.resellerid,b.resellername=a.resellername,b.rsladdress=a.reseller_address
from hdp.dbo.cgrt_2015_topup_final a join hdp.dbo.fr_callscdr2015 b on  
b.cli=a.mobileno    -- 

select  * from hdp.dbo.cgrt_2015_topup_final  -- 5059292

SELECT top 1100 *  FROM hdp.dbo.fr_callscdr2015


--NETWORK OPERATOR

select distinct cli,b.name,b.manager_name --into #test 
from hdp.dbo.fr_callscdr2015 a 
join cdr.dbo.account_name b on a.OprMask_B=b.trunk 
where cli is not null  ---  Records

alter table hdp.dbo.fr_callscdr2015 add network varchar(50)
alter table hdp.dbo.fr_callscdr2015 add mngrname varchar(50)

update b set b.network=a.name,b.mngrname=a.manager_name from cdr.dbo.account_name a
join hdp.dbo.fr_callscdr2015 b on b.OprMask_B=a.trunk   -- 3743494

select * from hdp.dbo.fr_callscdr2015



