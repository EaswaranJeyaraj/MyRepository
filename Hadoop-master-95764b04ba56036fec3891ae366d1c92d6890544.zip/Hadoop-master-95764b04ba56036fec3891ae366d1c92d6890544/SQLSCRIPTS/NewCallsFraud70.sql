--20/JULY/2016

--SQL SERVER SCRIPTS

-- CDR DATA -----

select * into hdp.dbo.cdr_2015_H from cdr.dbo.xcdr_fr_012015

alter table hdp.dbo.cdr_2015_H add idc int identity (1,1)

insert into hdp.dbo.cdr_2015_H select * from cdr.dbo.xcdr_fr_122015

select count(*) from hdp.dbo.cdr_2015_H	---9810917 -----

alter table hdp.dbo.cdr_2015_H add did_30 int
alter table hdp.dbo.cdr_2015_H add talk_70 int
alter table hdp.dbo.cdr_2015_H add talk_100 int
alter table hdp.dbo.cdr_2015_H add talk_200 int

select top 345 * from hdp.dbo.cdr_2015_H

update hdp.dbo.cdr_2015_H set did_30=3
update hdp.dbo.cdr_2015_H set talk_70=7
update hdp.dbo.cdr_2015_H set talk_100=10
update hdp.dbo.cdr_2015_H set talk_200=20


--GMS INCOMING DATA ---2015 ---

SELECT * into hdp.dbo.gms_2015_H from dbo.xgms_fr_012015

alter table hdp.dbo.gms_2015_H add idg int identity(1,1)

insert into hdp.dbo.gms_2015_H select * from dbo.xgms_fr_122015

select count(*) from hdp.dbo.gms_2015_H   --- 13760920 ---

SELECT top 365 * from hdp.dbo.gms_2015_H



---------------------------------------------------------------

--NETWORK OPERATOR


select  * from  account_name --Trunk 


select top 10  * from mrec_201605 --OprMask_B



select distinct cli,Domain_A,operator_a,cli,did,dialednum,destcode,domain_b,OprMask_B,operator_b,b.trunk,b.name,b.manager_name from mrec_201605 a 
join account_name b on a.OprMask_B=b.trunk



--MREC DATA 2015 ----


select * into hdp.dbo.mrec_2015_H from mrec201501 where domain_a='mfr'

alter table hdp.dbo.mrec_2015_H add idm int identity (1,1)

insert into hdp.dbo.mrec_2015_H select * from mrec201512  where domain_a='mfr'

select count(*) from hdp.dbo.mrec_2015_H  -- 9819348


---------------------------------------------------------------------------------------------

--100 MINUTES REPORT CDR,INCOMING,FIRSTUPDATE,BUNDLE,VOUCHER TARIFFCLASS,HISTORY
--------------------------------------------------------------------------------


--CALLS GREATER THAN 70 MINUTES

select distinct cli,convert(varchar(10),calldate,121)calldate,custcode CustomerCode,
destcode DestinationCode,did DestinationNo,destcode DestinationName,count(*) NoofCalls,sum(talktime)/60. MO_talktime,
datepart(hh,calldate) hrs,
datepart(mm,calldate) mnth,
tariffclass,domain_a into hdp.dbo.new_70_cdr
from hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR'
and datepart(hh,calldate) between 0 and 24
group by cli,convert(varchar(10),calldate,121),custcode,destcode,tariffclass,domain_a,did,
datepart(hh,calldate),datepart(mm,calldate)
having sum(talktime)/60.>=0
order by convert(varchar(10),calldate,121),datepart(hh,calldate),datepart(mm,calldate) --4207548

select * from hdp.dbo.new_70_cdr order by calldate  -- 3427

select distinct calldate from hdp.dbo.new_70_cdr

drop table hdp.dbo.new_70_cdr  -- 1381


--FIRST UPDATE

alter table hdp.dbo.new_70_cdr add firstupdate datetime



select mobileNo,a.iccid,convert(varchar(10),FirstUpdate,121) firstupdate into hdp.dbo.new_70_firstupdate 
FROM [CDR].[dbo].[mvno_account_H] a join [esp_mfr].[dbo].[SIM] b on
a.iccid=b.ICCID and mobileNo in(select  distinct ani from hdp.dbo.new_70_cdr) 
order by convert(varchar(10),FirstUpdate,121)  --1376 Records


--Updating FirstUpdate to Main Report Table

update b set b.firstupdate=a.FirstUpdate from hdp.dbo.new_70_firstupdate a
join hdp.dbo.new_70_cdr b on a.mobileno=b.ani -- 3416 Records



--INCOMING MINUTES


select msisdn,convert(varchar(10),calldate,121)calldate,sum(legadur)/60. incoming_min,
COUNT(*) noofincomingmin into hdp.dbo.new_70_incoming 
from [HDP].dbo.gms_2015_H
where msisdn  in (select distinct ani from hdp.dbo.new_70_cdr)
group by msisdn,convert(varchar(10),calldate,121)
order by calldate

select * from hdp.dbo.new_70_incoming order by calldate   -- 101485

alter table hdp.dbo.new_70_cdr add MT_talktime float
alter table hdp.dbo.new_70_cdr add MT_incomingmin_count int
alter table hdp.dbo.new_70_cdr drop column incoming_min 


--Updating Incoming MinutesRecords

update b set b.MT_talktime=a.incoming_min,b.MT_incomingmin_count=a.noofincomingmin from hdp.dbo.new_70_incoming a join
hdp.dbo.new_70_cdr b on b.cli COLLATE Latin1_General_CI_AS  =a.msisdn  COLLATE Latin1_General_CI_AS 
and convert(varchar(10),a.calldate,121)COLLATE Latin1_General_CI_AS  =convert(varchar(10),b.calldate,121)COLLATE Latin1_General_CI_AS  --2729406 

select * from hdp.dbo.new_70_cdr


--UPDATING BUNDLE RELATED DETAILS

select a.mobileno,iccid,a.bundleid,name bundlename,a.status,description,convert(varchar(10),startdate,121) startdate,
convert(varchar(10),enddate,121) enddate
into hdp.dbo.new_70_callbundle --Creating Temp Table for Bundle Info
from esp_mfr.dbo.mvno_bundle_plan a
join esp_mfr.dbo.bundle_plan b on a.bundleid=b.bundleid where a.status=1 
and a.mobileno in(select  distinct ani from hdp.dbo.new_70_cdr)  -- 15 Records

--TEMP TABLE FOR BUNDLE INFO
select * from hdp.dbo.new_70_callbundle -- 15 Records


alter table hdp.dbo.new_70_cdr add bundlename varchar(50)
alter table hdp.dbo.new_70_cdr add bstatus char(5)
alter table hdp.dbo.new_70_cdr add bstartdate datetime
alter table hdp.dbo.new_70_cdr add benddate datetime

SELECT * FROM hdp.dbo.new_70_cdr where bundlename is not null

update b set b.bundlename=a.bundlename,b.bstatus=a.status,b.bstartdate=a.startdate,
b.benddate=a.enddate from hdp.dbo.new_70_callbundle a join hdp.dbo.new_70_cdr b
on a.mobileno=b.ani --26 Records


--TOPUP

select count(*) NoOfTopups,b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,
convert(varchar(10),createdate,121) as topupdate,amount/100 amount,tp_tariffclass,calledby topuptype,
resellerid,fullname resellername,address reseller_address into hdp.dbo.new_70_tp_count -- Temp Table for Topup Details 4903
from esp_mfr.dbo.mvno_account b(nolock) join esp_mfr.dbo.topup_log a
on a.custcode=b.custcode and a.batchcode=b.batchcode and a.serialcode=b.serialcode
and a.mobileno=b.mobileno join esp_mfr.dbo.activation d      
on b.custcode=d.custcode and b.batchcode=d.batchcode and b.serialcode between d.serialcode_fr and d.serialcode_to      
inner join esp_mfr.dbo.reseller e(nolock) on d.sellerid=e.resellerid
where b.mobileno in(select  distinct ani from hdp.dbo.new_70_cdr)
and transstatusid=1 and b.mobileno is not null 
group by b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,convert(varchar(10),createdate,121),amount,tp_tariffclass,calledby,
resellerid,fullname,address 
order by   b.mobileno,convert(varchar(10),createdate,121)

select * from hdp.dbo.new_70_tp_count

select * from  hdp.dbo.new_70_tp_count--51112



--TOPUP MODE

select V_Tarcls_id,[V_Trff_CardName],[V_Tariffcls],[Denomination_id],b.V_Type_Id,[V_type] into .tmp_topup_mode 
  from [Master_Mundio].[dbo].[Vouchers_TariffCls] a
  join [Master_Mundio].[dbo].[Voucher_types] b on a.V_Type_Id=b.V_Type_Id
  
  --Final Topup
  
  select distinct mobileno,NoOfTopups,topupdate,amount tp_amount,tp_tariffclass,topuptype,resellerid,resellername,reseller_address,V_Trff_CardName Tariff,
  V_type into hdp.dbo.new_70_topup_final 
  from hdp.dbo.new_70_tp_count a join [HDP].[dbo].[tmp_topup_mode] b
  on a.tp_tariffclass=b.V_Tariffcls  order by topupdate -- 51033
  
  select * from hdp.dbo.new_70_topup_final 
  


alter table hdp.dbo.new_70_cdr drop column mode





--Altering Main Report Table (HDP.dbo.final_report) to accommodate the topup details

alter table hdp.dbo.new_70_cdr add topupdate datetime
alter table hdp.dbo.new_70_cdr add amount float
alter table hdp.dbo.new_70_cdr add tp_trffcls varchar(4)
alter table hdp.dbo.new_70_cdr add topupmode varchar(100)
alter table hdp.dbo.new_70_cdr add tariff varchar(200)
alter table hdp.dbo.new_70_cdr add topuptype varchar(15)
alter table hdp.dbo.new_70_cdr add resellerid int
alter table hdp.dbo.new_70_cdr add resellername varchar(512)
alter table hdp.dbo.new_70_cdr add rsladdress varchar(256)



--Updating Topup and Mode of Payment and Reseller Shopname Detail to Main Report Table
  
		--Updating HDP.dbo.final_report
  
  update b set b.topupdate=a.topupdate,b.tariff=a.Tariff,b.topuptype=a.topuptype,
b.amount=a.tp_amount,b.tp_trffcls=a.tp_tariffclass,b.topupmode=a.V_type,
b.resellerid=a.resellerid,b.resellername=a.resellername,b.rsladdress=a.reseller_address
from hdp.dbo.new_70_topup_final a join hdp.dbo.new_70_cdr b on  
b.ani=a.mobileno    -- 3219

select  * from hdp.dbo.new_70_topup_final  --3219

SELECT *  FROM hdp.dbo.new_70_cdr 


--NETWORK OPERATOR

select distinct cli,b.name,b.manager_name --into #test 
from HDP.dbo.mrec_2015_H a 
join hdp.dbo.new_70_cdr c on a.cli = c.ani
join cdr.dbo.account_name b on a.OprMask_B=b.trunk 
where cli is not null  --- 9144 Records

SELECT * FROM hdp.dbo.new_70_cdr



