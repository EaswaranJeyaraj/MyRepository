--The purpose of this report is to find out the CLI account  who is getting incoming 
--call from   more than or equal  to  5 destination in one day.

select top 3 * from dbo.gms_2015_H

select msisdn mobileno,convert(varchar(10),calldate,121) Calldate,count(distinct cli) DidCt,cli Did from dbo.gms_2015_H 
--where convert(varchar(10),calldate,121) = '2015-06-06' and fwd_discpty = 1 and msisdn = '33759461973'
group by msisdn,convert(varchar(10),calldate,121),cli
having count(distinct cli)>=1 --5653125


select  *from dbo.gms_2015_H where msisdn = '33759461973' and convert(varchar(10),calldate,121) = '2015-06-06' 
and fwd_discpty = 1

select * from sms.dbo.sms_operator_2015

select top 1 * from dbo.gms_2015_H

oing on


s

select convert(varchar(10),calldate,121) cidate,msisdn,sum(legadur)/60. MT_talktime,count(distinct cli) DidCt,
cli Did from dbo.gms_2015_H where msisdn='33759044556' and convert(varchar(10),calldate,121)='2015-01-01' 
group by convert(varchar(10),calldate,121),msisdn,cli    --33646263346    33659666819

select top 1 * from dbo.gms_2015_H


select msisdn,convert(varchar(10),calldate,121) Calldate,sum(legadur)/60. MT_talktime,count(cli) DidCt,
cli Did  --into #i 
from dbo.gms_2015_H where msisdn like '33%' and msisdn='33759044556' and 
convert(varchar(10),calldate,121)='2015-01-01' 
group by msisdn,convert(varchar(10),calldate,121),cli
having count(cli)>=1 



select calldate,msisdn,sum(legadur)/60. MT_talktime,
cli Did from dbo.gms_2015_H where msisdn='33759044556' and convert(varchar(10),calldate,121)='2015-01-01'  
and cli='918288938659'
group by calldate,msisdn,cli














select distinct msisdn,cmdate,
destcode DestinationCode,count(distinct(cli)) countofdid,destcode DestinationName,
count(*) NoofMOCalls,sum(talktime_inmin)MO_talktime,
datepart(hh,calldate) hrs,
datepart(mi,calldate) mins,
TariffClass,trffname,domain_a,oprmask_b
into hdp.dbo.fr_did_2015
from hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR'
group by cli,custcode,domain_a,TariffClass,trffname,destcode,
datepart(hh,calldate),datepart(mi,calldate),oprmask_b,cmdate
having count(distinct(did))>=0
order by cmdate 




-- FINAL QUERY
---------------


--The purpose of this report is to find out the CLI account  who is getting incoming 
--call from   more than or equal  to  5 destination in one day.

select convert(varchar(10),calldate,121) calldate,sitecode,a_trunk,msisdn mobileno,
 count(distinct cli) countofincoming,sum(legadur)/60. MT_talktime --into #in
from dbo.gms_2015_H where --convert(varchar(10),calldate,121)='2015-07-24' and 
fwd_discpty =1 and a_trunk<>'MFRMOBMV' 
and imsi between '208310001000000' and '208310001999999' 
group by convert(varchar(10),calldate,121),sitecode,a_trunk,msisdn
having  count(cli)>=5  -- 346460

