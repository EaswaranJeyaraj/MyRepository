--51--The purpose of this report is to find out the CLI account  who calls more than and 
--equal to 20 destination number each day and  sum of talk time min is greater and equal to  200 Min 
--and registration date is less than 20 days with no incoming minutes.

--HighTalkTimeUsuage (htu)
---------------------------

select distinct cli,cmdate,convert(varchar(10),calldate,121)calldate,
destcode DestinationCode,did DestinationNo,destcode DestinationName,
count(*) NoofCalls,sum(talktime_inmin)MO_talktime,count(did) didcount,
datepart(hh,calldate) hour,
datepart(mi,calldate) minutes,oprmask_b,
TariffClass,trffname,domain_a 
into hdp.dbo.fhtu_2015_cdr
from hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR' and cli like '33%'
group by cli,convert(varchar(10),calldate,121),custcode,domain_a,TariffClass,trffname,destcode,did,
datepart(hh,calldate),datepart(mi,calldate),oprmask_b,cmdate
having sum(talktime_inmin)>=0 and count(did)>=2
order by cmdate  -- 

drop table hdp.dbo.fhtu_2015_incoming



-------------------------------------------------------------------------------------------------------------
--TESTING NOT REQUIRED
select cli,cmdate,calldate,
destcode DestinationCode,did DestinationNo,destcode DestinationName,TariffClass,trffname,domain_a,
datepart(hh,calldate) hour,
datepart(mi,calldate) minutes,sum(talktime_inmin),oprmask_b,count(did) didcount
from hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR' and cli='33695550163' and cmdate='2015-12-01'
group by cli,calldate,custcode,domain_a,TariffClass,trffname,destcode,did,
datepart(hh,calldate),datepart(mi,calldate),oprmask_b,cmdate
having sum(talktime_inmin)>=0 and count(did)>=1

select * from  hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR' and cli='33695550163' and cmdate='2015-12-01'

select top 10 *from backup2011.dbo.mrec1201 where cli = '33695550163'  -- TESTING
------------------------------------------------------------------------------------------------------------------

select * from hdp.dbo.fhtu_2015_cdr


--FIRST UPDATE

alter table hdp.dbo.fhtu_2015_cdr add firstupdate datetime


select mobileNo,a.iccid,convert(varchar(10),FirstUpdate,121) firstupdate into hdp.dbo.fhtu_2015_firstupdate 
FROM [CDR].[dbo].[mvno_account_H] a join [esp_mfr].[dbo].[SIM] b on
a.iccid=b.ICCID and mobileNo in(select  distinct cli from hdp.dbo.fhtu_2015_cdr) 
order by convert(varchar(10),FirstUpdate,121)  --28564 Records


--Updating FirstUpdate to Main Report Table

update b set b.firstupdate=a.FirstUpdate from hdp.dbo.fhtu_2015_firstupdate  a
right join hdp.dbo.fhtu_2015_cdr b on a.mobileno=b.cli  -- 104001


--INCOMING MINUTES


select msisdn,convert(varchar(10),calldate,121)calldate,sum(legadur)/60. mt_talktime,
count(*) countofincomingmin into hdp.dbo.fhtu_2015_incoming 
from [HDP].dbo.gms_2015_H
where msisdn  in (select distinct cli from hdp.dbo.fhtu_2015_cdr)
group by msisdn,convert(varchar(10),calldate,121)
order by calldate -- 1487666

select top 43 * from hdp.dbo.fhtu_2015_incoming order by calldate   -- 2240004

alter table hdp.dbo.fhtu_2015_cdr add MT_talktime int
alter table hdp.dbo.fhtu_2015_cdr add MT_incomingmin_count int
alter table hdp.dbo.fhtu_2015_cdr drop column incoming_min 


--Updating Incoming MinutesRecords

update b set b.MT_talktime=a.mt_talktime,b.MT_incomingmin_count=a.countofincomingmin from hdp.dbo.fhtu_2015_incoming a right join
hdp.dbo.fhtu_2015_cdr b on b.cli=a.msisdn 
and convert(varchar(10),a.calldate,121)=convert(varchar(10),b.calldate,121) -- 104001

select top 4 * from hdp.dbo.fhtu_2015_cdr



--UPDATING BUNDLE RELATED DETAILS

select a.mobileno,iccid,a.bundleid,name bundlename,a.status,description,convert(varchar(10),startdate,121) startdate,
convert(varchar(10),enddate,121) enddate
into hdp.dbo.fhtu_2015_bundle --Creating Temp Table for Bundle Info
from esp_mfr.dbo.mvno_bundle_plan a
join esp_mfr.dbo.bundle_plan b on a.bundleid=b.bundleid where a.status=1 
and a.mobileno in(select  distinct cli from hdp.dbo.fhtu_2015_cdr)  -- 233 Records

--TEMP TABLE FOR BUNDLE INFO
select * from hdp.dbo.fhtu_2015_cdr -- 387 Records


alter table hdp.dbo.fhtu_2015_cdr add bundlename varchar(50)
alter table hdp.dbo.fhtu_2015_cdr add bstatus char(5)
alter table hdp.dbo.fhtu_2015_cdr add bstartdate datetime
alter table hdp.dbo.fhtu_2015_cdr add benddate datetime
alter table hdp.dbo.fhtu_2015_cdr add bdescription varchar(50)

SELECT * FROM hdp.dbo.fhtu_2015_cdr where bundlename is not null

update b set b.bundlename=a.bundlename,b.bstatus=a.status,b.bstartdate=a.startdate,
b.benddate=a.enddate,b.bdescription=a.description from hdp.dbo.fhtu_2015_bundle a 
right join hdp.dbo.fhtu_2015_cdr b
on a.mobileno=b.cli -- 104001 Records



--TOPUP

select count(*) NoOfTopups,b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,
convert(varchar(10),createdate,121) as topupdate,amount/100 amount,tp_tariffclass,calledby topuptype,
resellerid,fullname resellername,address reseller_address into hdp.dbo.fhtu_2015_tp_count -- Temp Table for Topup Details 4903
from esp_mfr.dbo.mvno_account b(nolock) join esp_mfr.dbo.topup_log a
on a.custcode=b.custcode and a.batchcode=b.batchcode and a.serialcode=b.serialcode
and a.mobileno=b.mobileno join esp_mfr.dbo.activation d      
on b.custcode=d.custcode and b.batchcode=d.batchcode and b.serialcode between d.serialcode_fr and d.serialcode_to      
inner join esp_mfr.dbo.reseller e(nolock) on d.sellerid=e.resellerid
where b.mobileno in(select  distinct cli from hdp.dbo.fhtu_2015_cdr)
and transstatusid=1 and b.mobileno is not null 
group by b.mobileno,b.iccid,b.custcode,b.serialcode,b.batchcode,convert(varchar(10),createdate,121),amount,tp_tariffclass,calledby,
resellerid,fullname,address 
order by   b.mobileno,convert(varchar(10),createdate,121)  -- 627707



select * from  hdp.dbo.fhtu_2015_tp_count--925340



--TOPUP MODE

select V_Tarcls_id,[V_Trff_CardName],[V_Tariffcls],[Denomination_id],b.V_Type_Id,[V_type] into hdp.dbo.tmp_topup_mode 
  from [Master_Mundio].[dbo].[Vouchers_TariffCls] a
  join [Master_Mundio].[dbo].[Voucher_types] b on a.V_Type_Id=b.V_Type_Id
  
  --Final Topup
  
  select distinct mobileno,NoOfTopups,topupdate,amount tp_amount,tp_tariffclass,topuptype,resellerid,resellername,reseller_address,V_Trff_CardName Tariff,
  V_type into hdp.dbo.fhtu_2015_topup_final 
  from hdp.dbo.fhtu_2015_tp_count a join [HDP].[dbo].[tmp_topup_mode] b
  on a.tp_tariffclass=b.V_Tariffcls  order by topupdate -- 627276
  
  select * from hdp.dbo.fhtu_2015_topup_final 
  select count(*) from hdp.dbo.fhtu_2015_topup_final 
  
  drop table hdp.dbo.fhtu_2015_topup_final
  


alter table hdp.dbo.fhtu_2015_topup_final drop column mode





--Altering Main Report Table (HDP.dbo.final_report) to accommodate the topup details

alter table hdp.dbo.fhtu_2015_cdr add topupdate datetime
alter table hdp.dbo.fhtu_2015_cdr add amount float
alter table hdp.dbo.fhtu_2015_cdr add tp_trffcls varchar(4)
alter table hdp.dbo.fhtu_2015_cdr add topupmode varchar(100)
alter table hdp.dbo.fhtu_2015_cdr add tariff varchar(200)
alter table hdp.dbo.fhtu_2015_cdr add topuptype varchar(15)
alter table hdp.dbo.fhtu_2015_cdr add resellerid int
alter table hdp.dbo.fhtu_2015_cdr add resellername varchar(512)
alter table hdp.dbo.fhtu_2015_cdr add rsladdress varchar(256)



--Updating Topup and Mode of Payment and Reseller Shopname Detail to Main Report Table
  
		--Updating HDP.dbo.final_report
  
  update b set b.topupdate=a.topupdate,b.tariff=a.Tariff,b.topuptype=a.topuptype,
b.amount=a.tp_amount,b.tp_trffcls=a.tp_tariffclass,b.topupmode=a.V_type,
b.resellerid=a.resellerid,b.resellername=a.resellername,b.rsladdress=a.reseller_address
from hdp.dbo.fhtu_2015_topup_final a right join hdp.dbo.fhtu_2015_cdr b on  
b.cli=a.mobileno    --  104001


SELECT top 1100 *  FROM hdp.dbo.fhtu_2015_cdr


--NETWORK OPERATOR

select distinct cli,b.name,b.manager_name --into #test 
from hdp.dbo.fhtu_2015_cdr a 
join cdr.dbo.account_name b on a.OprMask_B=b.trunk 
where cli is not null  ---  Records

alter table hdp.dbo.fhtu_2015_cdr add network varchar(50)
alter table hdp.dbo.fhtu_2015_cdr add mngrname varchar(50)

update b set b.network=a.name,b.mngrname=a.manager_name from cdr.dbo.account_name a
right join hdp.dbo.fhtu_2015_cdr b on b.OprMask_B=a.trunk   -- 104001



----FINAL TESTING--------
select * from hdp.dbo.fhtu_2015_cdr where didcount>2
select * from hdp.dbo.fhtu_2015_cdr where TRFFNAME='N/A' 


select  * from hdp.dbo.mrec_2015_hp where cli='33759001932' and calldate='2015-10-08' and mi=35
select * from  hdp.dbo.mrec_2015_hp 
where destcode not like '%Voicemail%' and destcode not like '%Customerservice%' and destcode not like '%Topup%' 
and domain_a='MFR' and cli='33759014613' and cmdate='2015-06-11' and mi=44

 --DID --655802409759470549