--The purpose of this report is to find out the CLI account  who is getting incoming 
--call from   more than or equal  to  5 destination in one day.

select convert(varchar(10),calldate,121) calldate,sitecode,a_trunk,msisdn mobileno,
 count(cli) countofincoming,sum(legadur)/60. MT_talktime  
from hdp.dbo.gms_2015_H where --convert(varchar(10),calldate,121)='2015-07-24' and 
fwd_discpty =1 and a_trunk<>'MFRMOBMV' --and msisdn='33759777552' and  convert(varchar(10),calldate,121)='2015-06-08'
and imsi between '208310001000000' and '208310001999999' 
group by convert(varchar(10),calldate,121),sitecode,a_trunk,msisdn
having count(cli)>=5
order by count(cli) desc -- 346460

select count(*) from #in


-- TESTING ---------------------------------------------------------------------------------------

select calldate,sitecode,a_trunk,msisdn mobileno,
 sum(legadur)/60. MT_talktime from HDP.dbo.gms_2015_H where --convert(varchar(10),calldate,121)='2015-07-24' and 
fwd_discpty =1 and a_trunk<>'MFRMOBMV' 
and imsi between '208310001000000' and '208310001999999' and convert(varchar(10),calldate,121)='2015-06-08' and 
msisdn='33759777552' and sitecode='MFR' and a_trunk='sfrtamun'
group by calldate,sitecode,a_trunk,msisdn


select calldate,sitecode,a_trunk,msisdn mobileno,
 sum(legadur)/60. MT_talktime from HDP.dbo.gms_2015_H where --convert(varchar(10),calldate,121)='2015-07-24' and 
fwd_discpty =1 and a_trunk<>'MFRMOBMV' 
and imsi between '208310001000000' and '208310001999999' and convert(varchar(10),calldate,121)='2015-03-09' and 
msisdn='33759605748' and sitecode='MFR' and a_trunk='sfrtamun'
group by calldate,sitecode,a_trunk,msisdn

calldate	sitecode	a_trunk	mobileno	countofincoming	MT_talktime
2015-03-09	MFR	sfrtamun	33759605748	3	5.983333


select calldate,sitecode,a_trunk,msisdn mobileno,
 sum(legadur)/60. MT_talktime from HDP.dbo.gms_2015_H where --convert(varchar(10),calldate,121)='2015-07-24' and 
fwd_discpty =1 and a_trunk<>'MFRMOBMV' 
and imsi between '208310001000000' and '208310001999999' and convert(varchar(10),calldate,121)='2015-02-25' and 
msisdn='33759385625' and sitecode='MFR' and a_trunk='sfrtamun'
group by calldate,sitecode,a_trunk,msisdn

