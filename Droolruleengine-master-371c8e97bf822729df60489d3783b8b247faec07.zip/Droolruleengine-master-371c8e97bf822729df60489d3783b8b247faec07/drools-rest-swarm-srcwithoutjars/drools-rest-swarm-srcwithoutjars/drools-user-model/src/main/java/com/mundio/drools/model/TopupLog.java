package com.mundio.drools.model;

import java.util.Date;

/**
 * Created by sinchan on 12/06/17.
 */
public class TopupLog {

    private int paymentType;
    private Date createdate;
    private int transstatusID;
    private float prevbal;
    private float afterbal;
    private String currcode;
    //private String calledby;
    private String tpTariffclass;

    public int getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(int paymentType) {
        this.paymentType = paymentType;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public int getTransstatusID() {
        return transstatusID;
    }

    public void setTransstatusID(int transstatusID) {
        this.transstatusID = transstatusID;
    }

    public float getPrevbal() {
        return prevbal;
    }

    public void setPrevbal(float prevbal) {
        this.prevbal = prevbal;
    }

    public float getAfterbal() {
        return afterbal;
    }

    public void setAfterbal(float afterbal) {
        this.afterbal = afterbal;
    }

    public String getCurrcode() {
        return currcode;
    }

    public void setCurrcode(String currcode) {
        this.currcode = currcode;
    }

/*    public String getCalledby() {
        return calledby;
    }

    public void setCalledby(String calledby) {
        this.calledby = calledby;
    }*/

    public String getTpTariffclass() {
        return tpTariffclass;
    }

    public void setTpTariffclass(String tpTariffclass) {
        this.tpTariffclass = tpTariffclass;
    }
}
