package com.mundio.drools.customfunction;

import java.util.Date;
/**
 * Created by hadoop on 6/3/17.
 */
public class ExpiryDateCustomFunction {
    public static long TimediffBundleNearExpiryTestDateCF(Date testDate){
        // The content of this method is Java
        if(testDate==null)
            return Integer.MAX_VALUE;
        return (testDate.getTime() - new Date().getTime())/(24 * 60 * 60 * 1000);
    }
}
