package com.mundio.drools.customfunction;

import com.mundio.drools.model.BundleLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hadoop on 6/27/17.
 */
public class MAUtility {

public static List<BundleLog> getBundleLogsWithBundleId(List<BundleLog> bundleLogs,int bundleId,int status){
    List<BundleLog> bundleLogsFiltered = new ArrayList<BundleLog>();
    for(BundleLog bundleLog : bundleLogs){
        if(bundleLog.getBundleID() == bundleId && bundleLog.getBundleLogstatus() == status && bundleLog.getProcessName().equals("subscribe")){
            bundleLogsFiltered.add(bundleLog);
        }
    }
    return bundleLogsFiltered;
}
}
