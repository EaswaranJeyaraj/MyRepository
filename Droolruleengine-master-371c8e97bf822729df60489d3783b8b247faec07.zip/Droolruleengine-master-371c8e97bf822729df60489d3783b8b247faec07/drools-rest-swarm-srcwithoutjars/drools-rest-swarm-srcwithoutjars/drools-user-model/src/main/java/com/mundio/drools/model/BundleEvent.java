package com.mundio.drools.model;

import java.io.Serializable;
import java.util.Date;

public class BundleEvent implements Serializable {

	// Subscriber SQL Table Name For Reference Purpose

	private int subscriberID; // Customer Subscriber ID
	private String firstName; // Customer First Name
	private String lastName; // Customer Last Name
	private String email; // Customer EMail
	private Date activationDate;
	private String actionType;
	private int paymentType;
	private Date createdate;
	private int transstatusID;
	private float prevbal;
	private float afterbal;
	private String currcode;

	//private String calledby;
	private String updateBy;
	private String tpTariffclass;

	private int bundleID; // ID for Each Bundle
	private String siteCode; // To Differentiate the Country
	private String bundleName; // Name of the Bundle
	private double price; // Bundle Price
	private String currency; // Bundle Currency
	private int status; // Bundle Status
	private int renewalMode; // Renewal Methods for the Bundle
	private int renewalDelay;
	private int mainBundleGroupID;
	private int familyGroupID;
	private int tariffClassGroupID;
	private int bundleGroupID;


	// [bundle_plan_package]

	private int packageID; // Package ID
	private double packageBalance;


	// [mvno_bundle_plan]

	private String iccID; // Unique ID for Customer
	private String mobileNo; // Customer Mobile No
	private Date joinDate;
	private Date stopDate;
	private Date lastUpdate;
	private int payMode; // payment method for this process. 0: free payment 1:
	// debiting from master 2: debiting from CCDC 3:
	// free
	private Date startDate; // the startdate for each bundle subscription cycle
	private Date endDate; // the enddate for each bundle subscription cycle
	private int mvbpStatus; // status for each bundle on this user. 1: active 2:
	// inactive 3: suspended 4: need to renew/repay

	private int paymentFlag; // the payment flag that related to renewal

	// [mvno_account]

	private String custCode;
	private int batchCode;
	private int serialCode;
	private Date renewStartDate;
	private Date renewDuedate;


	// [account_package] accpkg

	private double accPkgBalance; // Initial Balance, Divide the Value by 100 to
	// get the Exact Balance
	private String currCode;
	private String mCustCode;
	private int mBatchCode;
	private int mSerialCode;
	private int packageType; // To differentiate Call / SMS / GPRS
	private Date accPkgLastUpdate;

	// account

	private String accTrffClass; // Master Tariff Class
	private double accBalance; // Current Balance, Divide the Value by 100 to
	// get the Exact Balance
	private double totalCons; // Data Consumed will be stored here
	private double monthLim;
	private double totalCost;
	private int accStatus;

	// package

	private String pkgName; // Package Name
	private String pkgTariffClass; // Bundle Tariff Class
	private int packageTypeID;
	private int duration;
	private String ussdInfoText;
	private int flagToBuyBundle;

	// package_template

	private int daysValid;
	private Date expiredDate;
	private int expdateMode;

	// Sim

	private int subscriberStatus; // Subscriber Status
	private Date firstUpdate; // Customer First Login Date
	// bundle plan

	// [bundle_log] bundleLog

	//private int packageID;
	private Date logDate;

	private String processName;

	//private int bundleID;
	//private Date startDate;
	//private Date endDate;
	private int bundleLogStatus;
	//private String mobileNo;

	public int getBundleLogStatus() {
		return bundleLogStatus;
	}

	public void setBundleLogStatus(int bundleLogStatus) {
		this.bundleLogStatus = bundleLogStatus;
	}

	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public int getSubscriberID() {
		return subscriberID;
	}

	public void setSubscriberID(int subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public int getBundleID() {
		return bundleID;
	}

	public void setBundleID(int bundleID) {
		this.bundleID = bundleID;
	}

	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	public String getBundleName() {
		return bundleName;
	}

	public void setBundleName(String bundleName) {
		this.bundleName = bundleName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getRenewalMode() {
		return renewalMode;
	}

	public void setRenewalMode(int renewalMode) {
		this.renewalMode = renewalMode;
	}

	public int getRenewalDelay() {
		return renewalDelay;
	}

	public void setRenewalDelay(int renewalDelay) {
		this.renewalDelay = renewalDelay;
	}

	public int getMainBundleGroupID() {
		return mainBundleGroupID;
	}

	public void setMainBundleGroupID(int mainBundleGroupID) {
		this.mainBundleGroupID = mainBundleGroupID;
	}

	public int getFamilyGroupID() {
		return familyGroupID;
	}

	public void setFamilyGroupID(int familyGroupID) {
		this.familyGroupID = familyGroupID;
	}

	public int getTariffClassGroupID() {
		return tariffClassGroupID;
	}

	public void setTariffClassGroupID(int tariffClassGroupID) {
		this.tariffClassGroupID = tariffClassGroupID;
	}

	public int getBundleGroupID() {
		return bundleGroupID;
	}

	public void setBundleGroupID(int bundleGroupID) {
		this.bundleGroupID = bundleGroupID;
	}

	public int getPackageID() {
		return packageID;
	}

	public void setPackageID(int packageID) {
		this.packageID = packageID;
	}

	public double getPackageBalance() {
		return packageBalance;
	}

	public void setPackageBalance(double packageBalance) {
		this.packageBalance = packageBalance;
	}

	public String getIccID() {
		return iccID;
	}

	public void setIccID(String iccID) {
		this.iccID = iccID;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public Date getStopDate() {
		return stopDate;
	}

	public void setStopDate(Date stopDate) {
		this.stopDate = stopDate;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getPayMode() {
		return payMode;
	}

	public void setPayMode(int payMode) {
		this.payMode = payMode;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getMvbpStatus() {
		return mvbpStatus;
	}

	public void setMvbpStatus(int mvbpStatus) {
		this.mvbpStatus = mvbpStatus;
	}

	public int getPaymentFlag() {
		return paymentFlag;
	}

	public void setPaymentFlag(int paymentFlag) {
		this.paymentFlag = paymentFlag;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public int getBatchCode() {
		return batchCode;
	}

	public void setBatchCode(int batchCode) {
		this.batchCode = batchCode;
	}

	public int getSerialCode() {
		return serialCode;
	}

	public void setSerialCode(int serialCode) {
		this.serialCode = serialCode;
	}

	public Date getRenewStartDate() {
		return renewStartDate;
	}

	public void setRenewStartDate(Date renewStartDate) {
		this.renewStartDate = renewStartDate;
	}

	public Date getRenewDuedate() {
		return renewDuedate;
	}

	public void setRenewDuedate(Date renewDuedate) {
		this.renewDuedate = renewDuedate;
	}

	public double getAccPkgBalance() {
		return accPkgBalance;
	}

	public void setAccPkgBalance(double accPkgBalance) {
		this.accPkgBalance = accPkgBalance;
	}

	public String getCurrCode() {
		return currCode;
	}

	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}

	public String getmCustCode() {
		return mCustCode;
	}

	public void setmCustCode(String mCustCode) {
		this.mCustCode = mCustCode;
	}

	public int getmBatchCode() {
		return mBatchCode;
	}

	public void setmBatchCode(int mBatchCode) {
		this.mBatchCode = mBatchCode;
	}

	public int getmSerialCode() {
		return mSerialCode;
	}

	public void setmSerialCode(int mSerialCode) {
		this.mSerialCode = mSerialCode;
	}

	public int getPackageType() {
		return packageType;
	}

	public void setPackageType(int packageType) {
		this.packageType = packageType;
	}

	public Date getAccPkgLastUpdate() {
		return accPkgLastUpdate;
	}

	public void setAccPkgLastUpdate(Date accPkgLastUpdate) {
		this.accPkgLastUpdate = accPkgLastUpdate;
	}

	public String getAccTrffClass() {
		return accTrffClass;
	}

	public void setAccTrffClass(String accTrffClass) {
		this.accTrffClass = accTrffClass;
	}

	public double getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	public double getTotalCons() {
		return totalCons;
	}

	public void setTotalCons(double totalCons) {
		this.totalCons = totalCons;
	}

	public double getMonthLim() {
		return monthLim;
	}

	public void setMonthLim(double monthLim) {
		this.monthLim = monthLim;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public int getAccStatus() {
		return accStatus;
	}

	public void setAccStatus(int accStatus) {
		this.accStatus = accStatus;
	}

	public String getPkgName() {
		return pkgName;
	}

	public void setPkgName(String pkgName) {
		this.pkgName = pkgName;
	}

	public String getPkgTariffClass() {
		return pkgTariffClass;
	}

	public void setPkgTariffClass(String pkgTariffClass) {
		this.pkgTariffClass = pkgTariffClass;
	}

	public int getPackageTypeID() {
		return packageTypeID;
	}

	public void setPackageTypeID(int packageTypeID) {
		this.packageTypeID = packageTypeID;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getUssdInfoText() {
		return ussdInfoText;
	}

	public void setUssdInfoText(String ussdInfoText) {
		this.ussdInfoText = ussdInfoText;
	}

	public int getFlagToBuyBundle() {
		return flagToBuyBundle;
	}

	public void setFlagToBuyBundle(int flagToBuyBundle) {
		this.flagToBuyBundle = flagToBuyBundle;
	}

	public int getDaysValid() {
		return daysValid;
	}

	public void setDaysValid(int daysValid) {
		this.daysValid = daysValid;
	}

	public Date getExpiredDate() {
		return expiredDate;
	}

	public void setExpiredDate(Date expiredDate) {
		this.expiredDate = expiredDate;
	}

	public int getExpdateMode() {
		return expdateMode;
	}

	public void setExpdateMode(int expdateMode) {
		this.expdateMode = expdateMode;
	}

	public int getSubscriberStatus() {
		return subscriberStatus;
	}

	public void setSubscriberStatus(int subscriberStatus) {
		this.subscriberStatus = subscriberStatus;
	}

	public Date getFirstUpdate() {
		return firstUpdate;
	}

	public void setFirstUpdate(Date firstUpdate) {
		this.firstUpdate = firstUpdate;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public int getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(int paymentType) {
		this.paymentType = paymentType;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public int getTransstatusID() {
		return transstatusID;
	}

	public void setTransstatusID(int transstatusID) {
		this.transstatusID = transstatusID;
	}

	public float getPrevbal() {
		return prevbal;
	}

	public void setPrevbal(float prevbal) {
		this.prevbal = prevbal;
	}

	public float getAfterbal() {
		return afterbal;
	}

	public void setAfterbal(float afterbal) {
		this.afterbal = afterbal;
	}

	public String getCurrcode() {
		return currcode;
	}

	public void setCurrcode(String currcode) {
		this.currcode = currcode;
	}

	/*public String getCalledby() {
		return calledby;
	}

	public void setCalledby(String calledby) {
		this.calledby = calledby;
	}*/

	public String getTpTariffclass() {
		return tpTariffclass;
	}

	public void setTpTariffclass(String tpTariffclass) {
		this.tpTariffclass = tpTariffclass;
	}
}