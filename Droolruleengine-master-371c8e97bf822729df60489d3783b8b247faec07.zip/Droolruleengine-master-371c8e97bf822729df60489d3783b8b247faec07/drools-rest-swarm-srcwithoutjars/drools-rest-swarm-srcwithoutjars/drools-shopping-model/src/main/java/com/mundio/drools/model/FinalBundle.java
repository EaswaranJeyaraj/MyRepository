package com.mundio.bundle.rules;

import java.io.Serializable;
import java.util.Date;

public class FinalBundle implements Serializable {


		/* Common Fields */
	private String sendsms;
	private String sendsmsdetail;
	private String blockcall;
	private String blockcalldetail;
	private String blocknumber;// : String
	private String blocknumberdetail;
	private String sendpush;// String
	private String sendpushdetail;
	private String sendmail;// String
	private String sendmaildetail;
	
	
	// Final Bundle Columns

	// Subscriber SQL Table Name For Reference Purpose

	private int subscriberid; // Customer Subscriber ID
	private String firstname; // Customer First Name
	private String lastname; // Customer Last Name
	private String email; // Customer EMail
	private Date activationdate;
	

	// bundle plan

	private int bundleID; // ID for Each Bundle
	private String sitecode; // To Differentiate the Country
	private String bundleName; // Name of the Bundle
	private double price; // Bundle Price
	private String currency; // Bundle Currency
	private int status; // Bundle Status
	private int renewalMode; // Renewal Methods for the Bundle
	private int renewalDelay;
	private int mainbundleGroupID;
	private int familyGroupID;
	private int tariffclassGroupID;
	private int bundleGroupID;
	

	// [bundle_plan_package]

	private int packageID; // Package ID
	private double packagebalance;
	

	// [mvno_bundle_plan]

	private String iccID; // Unique ID for Customer
	private String mobileno; // Customer Mobile No
	private Date joindate;
	private Date stopdate;
	private Date lastupdate;
	private int paymode; // payment method for this process. 0: free payment 1:
							// debiting from master 2: debiting from CCDC 3:
							// free
	private Date startdate; // the startdate for each bundle subscription cycle
	private Date enddate; // the enddate for each bundle subscription cycle
	private int mvbpStatus; // status for each bundle on this user. 1: active 2:
							// inactive 3: suspended 4: need to renew/repay

	private int paymentFlag; // the payment flag that related to renewal

	// [mvno_account]

	private String custcode;
	private int batchcode;
	private int serialcode;
	private Date renewStartdate;
	private Date renewDuedate;
	

	// [account_package] accpkg

	private double accpkgBalance; // Initial Balance, Divide the Value by 100 to
									// get the Exact Balance
	private String currcode;
	private String mCustcode;
	private int mBatchcode;
	private int mSerialcode;
	private int packagetype; // To differentiate Call / SMS / GPRS
	private Date accpkgLastupdate;
	

	// account

	private String accTrffclass; // Master Tariff Class
	private double accBalance; // Current Balance, Divide the Value by 100 to
								// get the Exact Balance
	private double totalcons; // Data Consumed will be stored here
	private double monthlim;
	private double totalcost;
	private int accStatus;
	

	// package

	private String pkgName; // Package Name
	private String pkgTariffclass; // Bundle Tariff Class
	private int packageTypeID;
	private int duration;
	private String ussdInfoText;
	private int flagTobuyBundle;
	

	// package_template

	private int daysvalid;
	private Date expireddate;
	private int expdateMode;
	

	// Sim

	private int subscriberStatus; // Subscriber Status
	private Date firstUpdate; // Customer First Login Date
	
	

	// Getters and Setters

	public int getSubscriberid() {
		return subscriberid;
	}

	public void setSubscriberid(int subscriberid) {
		this.subscriberid = subscriberid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getActivationdate() {
		return activationdate;
	}

	public void setActivationdate(Date activationdate) {
		this.activationdate = activationdate;
	}

	public int getBundleID() {
		return bundleID;
	}

	public void setBundleID(int bundleID) {
		this.bundleID = bundleID;
	}

	public String getSitecode() {
		return sitecode;
	}

	public void setSitecode(String sitecode) {
		this.sitecode = sitecode;
	}

	public String getBundleName() {
		return bundleName;
	}

	public void setBundleName(String bundleName) {
		this.bundleName = bundleName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getRenewalMode() {
		return renewalMode;
	}

	public void setRenewalMode(int renewalMode) {
		this.renewalMode = renewalMode;
	}

	public int getRenewalDelay() {
		return renewalDelay;
	}

	public void setRenewalDelay(int renewalDelay) {
		this.renewalDelay = renewalDelay;
	}

	public int getMainbundleGroupID() {
		return mainbundleGroupID;
	}

	public void setMainbundleGroupID(int mainbundleGroupID) {
		this.mainbundleGroupID = mainbundleGroupID;
	}

	public int getFamilyGroupID() {
		return familyGroupID;
	}

	public void setFamilyGroupID(int familyGroupID) {
		this.familyGroupID = familyGroupID;
	}

	public int getTariffclassGroupID() {
		return tariffclassGroupID;
	}

	public void setTariffclassGroupID(int tariffclassGroupID) {
		this.tariffclassGroupID = tariffclassGroupID;
	}

	public int getBundleGroupID() {
		return bundleGroupID;
	}

	public void setBundleGroupID(int bundleGroupID) {
		this.bundleGroupID = bundleGroupID;
	}

	public int getPackageID() {
		return packageID;
	}

	public void setPackageID(int packageID) {
		this.packageID = packageID;
	}

	public double getPackagebalance() {
		return packagebalance;
	}

	public void setPackagebalance(double packagebalance) {
		this.packagebalance = packagebalance;
	}

	public String getIccID() {
		return iccID;
	}

	public void setIccID(String iccID) {
		this.iccID = iccID;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public Date getJoindate() {
		return joindate;
	}

	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}

	public Date getStopdate() {
		return stopdate;
	}

	public void setStopdate(Date stopdate) {
		this.stopdate = stopdate;
	}

	public Date getLastupdate() {
		return lastupdate;
	}

	public void setLastupdate(Date lastupdate) {
		this.lastupdate = lastupdate;
	}

	public int getPaymode() {
		return paymode;
	}

	public void setPaymode(int paymode) {
		this.paymode = paymode;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public int getMvbpStatus() {
		return mvbpStatus;
	}

	public void setMvbpStatus(int mvbpStatus) {
		this.mvbpStatus = mvbpStatus;
	}

	public int getPaymentFlag() {
		return paymentFlag;
	}

	public void setPaymentFlag(int paymentFlag) {
		this.paymentFlag = paymentFlag;
	}

	public String getCustcode() {
		return custcode;
	}

	public void setCustcode(String custcode) {
		this.custcode = custcode;
	}

	public int getBatchcode() {
		return batchcode;
	}

	public void setBatchcode(int batchcode) {
		this.batchcode = batchcode;
	}

	public int getSerialcode() {
		return serialcode;
	}

	public void setSerialcode(int serialcode) {
		this.serialcode = serialcode;
	}

	public Date getRenewStartdate() {
		return renewStartdate;
	}

	public void setRenewStartdate(Date renewStartdate) {
		this.renewStartdate = renewStartdate;
	}

	public Date getRenewDuedate() {
		return renewDuedate;
	}

	public void setRenewDuedate(Date renewDuedate) {
		this.renewDuedate = renewDuedate;
	}

	public double getAccpkgBalance() {
		return accpkgBalance;
	}

	public void setAccpkgBalance(double accpkgBalance) {
		this.accpkgBalance = accpkgBalance;
	}

	public String getCurrcode() {
		return currcode;
	}

	public void setCurrcode(String currcode) {
		this.currcode = currcode;
	}

	public String getmCustcode() {
		return mCustcode;
	}

	public void setmCustcode(String mCustcode) {
		this.mCustcode = mCustcode;
	}

	public int getmBatchcode() {
		return mBatchcode;
	}

	public void setmBatchcode(int mBatchcode) {
		this.mBatchcode = mBatchcode;
	}

	public int getmSerialcode() {
		return mSerialcode;
	}

	public void setmSerialcode(int mSerialcode) {
		this.mSerialcode = mSerialcode;
	}

	public int getPackagetype() {
		return packagetype;
	}

	public void setPackagetype(int packagetype) {
		this.packagetype = packagetype;
	}

	public Date getAccpkgLastupdate() {
		return accpkgLastupdate;
	}

	public void setAccpkgLastupdate(Date accpkgLastupdate) {
		this.accpkgLastupdate = accpkgLastupdate;
	}

	public String getAccTrffclass() {
		return accTrffclass;
	}

	public void setAccTrffclass(String accTrffclass) {
		this.accTrffclass = accTrffclass;
	}

	public double getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	public double getTotalcons() {
		return totalcons;
	}

	public void setTotalcons(double totalcons) {
		this.totalcons = totalcons;
	}

	public double getMonthlim() {
		return monthlim;
	}

	public void setMonthlim(double monthlim) {
		this.monthlim = monthlim;
	}

	public double getTotalcost() {
		return totalcost;
	}

	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}

	public int getAccStatus() {
		return accStatus;
	}

	public void setAccStatus(int accStatus) {
		this.accStatus = accStatus;
	}

	public String getPkgName() {
		return pkgName;
	}

	public void setPkgName(String pkgName) {
		this.pkgName = pkgName;
	}

	public String getPkgTariffclass() {
		return pkgTariffclass;
	}

	public void setPkgTariffclass(String pkgTariffclass) {
		this.pkgTariffclass = pkgTariffclass;
	}

	public int getPackageTypeID() {
		return packageTypeID;
	}

	public void setPackageTypeID(int packageTypeID) {
		this.packageTypeID = packageTypeID;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getUssdInfoText() {
		return ussdInfoText;
	}

	public void setUssdInfoText(String ussdInfoText) {
		this.ussdInfoText = ussdInfoText;
	}

	public int getFlagTobuyBundle() {
		return flagTobuyBundle;
	}

	public void setFlagTobuyBundle(int flagTobuyBundle) {
		this.flagTobuyBundle = flagTobuyBundle;
	}

	public int getDaysvalid() {
		return daysvalid;
	}

	public void setDaysvalid(int daysvalid) {
		this.daysvalid = daysvalid;
	}

	public Date getExpireddate() {
		return expireddate;
	}

	public void setExpireddate(Date expireddate) {
		this.expireddate = expireddate;
	}

	public int getExpdateMode() {
		return expdateMode;
	}

	public void setExpdateMode(int expdateMode) {
		this.expdateMode = expdateMode;
	}

	public int getSubscriberStatus() {
		return subscriberStatus;
	}

	public void setSubscriberStatus(int subscriberStatus) {
		this.subscriberStatus = subscriberStatus;
	}

	public Date getFirstUpdate() {
		return firstUpdate;
	}

	public void setFirstUpdate(Date firstUpdate) {
		this.firstUpdate = firstUpdate;
	}

}
