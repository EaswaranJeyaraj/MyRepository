public class CZTariffClass {

    public enum TariffClass {
        CNC1, CNT1, CND1, CNC2, CNT2, CND2, CNC3, CNT3, CND3;


		/*private String value;
		TariffClass(String value) {
			this.value = value;
		}
		public String getValue() {
			return value;
		}*/
    }

}