package org.drools.workshop.endpoint.api;

//import com.mundio.drools.mamodelpack.CustomerFact;
//import com.mundio.drools.mamodelpack.Facts;
import com.mundio.drools.model.Action;
import com.mundio.drools.model.BundleCases;

import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 * Created by sinchan on 09/04/17.
 */
@Path("facts")
public interface FactService {

/*

    @POST
    @Consumes("application/json")
    @Produces("application/json")
    @Path("/apply")
    public Facts eval(@NotNull Facts facts);
*/


   /* @POST
    @Consumes("application/json")
    @Produces("application/json")
    @Path("/customer")
    public CustomerFact evalCust(@NotNull CustomerFact facts);*/

   /* @POST
    @Consumes("application/json")
    @Produces("application/json")
    @Path("/bundle")//change the path
    public FinalBundle evalBundle(@NotNull FinalBundle facts);*/

    @POST
    @Consumes("application/json")
    @Produces("application/json")
    @Path("/bundle")//change the path
    public Action evalBundleCase(@NotNull BundleCases facts);
}
