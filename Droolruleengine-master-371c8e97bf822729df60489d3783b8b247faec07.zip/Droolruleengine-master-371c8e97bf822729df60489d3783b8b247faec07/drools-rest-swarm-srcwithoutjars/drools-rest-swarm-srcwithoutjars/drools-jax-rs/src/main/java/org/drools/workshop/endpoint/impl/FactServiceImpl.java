package org.drools.workshop.endpoint.impl;

//import com.mundio.drools.mamodelpack.CustomerFact;
//import com.mundio.drools.mamodelpack.Facts;
import com.mundio.drools.model.Action;
import com.mundio.drools.model.BundleCases;
import org.drools.workshop.endpoint.api.FactService;
import org.kie.api.cdi.KReleaseId;
import org.kie.api.cdi.KSession;
import org.kie.api.runtime.KieSession;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;

/**
 *
 * @author salaboy
 */
@ApplicationScoped
public class FactServiceImpl implements FactService {

    @Inject
    @KReleaseId(groupId = "org.drools.workshop", artifactId = "drools-user-kjar", version = "1.0-SNAPSHOT")
    @KSession
    private KieSession kSession;
    int count = 0;

    public FactServiceImpl() {
    }


 /*   @Override
    public Facts eval(@NotNull Facts facts) {
        System.out.println(">> kSession: " + kSession);
        printKieSessionAllFacts(kSession);
        System.out.println(">> facts: " + facts);
        kSession.insert(facts);
        int fired = kSession.fireAllRules();
        System.out.println(">> Fired: " + fired);
        return facts;
    }*/

  /*  @Override
    public CustomerFact evalCust(@NotNull CustomerFact facts) {
        System.out.println(">> kSession: " + kSession);
        printKieSessionAllFacts(kSession);
        System.out.println(">> customer facts: " + facts);
        kSession.insert(facts);
        int fired = kSession.fireAllRules();
        System.out.println(">> Fired: " + fired);
        return facts;
    }*/

    @Override
    public Action evalBundleCase(BundleCases facts) {
        System.out.println(">> kSession: " + kSession);
        printKieSessionAllFacts(kSession);
        System.out.println(">> bundle facts: " + facts);
        kSession.insert(facts);
        int fired = kSession.fireAllRules();
        System.out.println(">> Fired: " + fired);
        if(fired > 0){ count++; System.out.println("#NO of rules Fired"+count);
            return facts.getAction();
        }
        Action  action = new Action();
        action.setMobileNo(facts.getMobileNo());
        action.setEmail(facts.getEmail());
        return action;

    }

   /* @Override
    public FinalBundle evalBundle(FinalBundle facts) {
        System.out.println(">> kSession: " + kSession);
        printKieSessionAllFacts(kSession);
        System.out.println(">> bundle facts: " + facts);
        kSession.insert(facts);
        int fired = kSession.fireAllRules();
        System.out.println(">> Fired: " + fired);
        if(fired > 0){ count++; System.out.println("#NO of rules Fired"+count);};
        return facts;
    }*/


    private void printKieSessionAllFacts(KieSession kSession) {
        System.out.println(" >> Start - Printing All Facts in the Kie Session");
        for (Object o : kSession.getObjects()) {
            System.out.println(">> Fact: " + o);
        }
        System.out.println(" >> End - Printing All Facts in the Kie Session");
    }
}
