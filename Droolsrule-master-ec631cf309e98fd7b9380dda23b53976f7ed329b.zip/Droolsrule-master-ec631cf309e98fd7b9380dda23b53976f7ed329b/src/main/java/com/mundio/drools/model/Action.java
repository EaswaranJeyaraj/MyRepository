package com.mundio.drools.model;

/**
 * Created by hadoop on 7/5/17.
 */
public class Action {

    private String sendSms="No";
    private String sendSmsDetail;
    private String blockCall="No";
    private String blockCallDetail;
    private String blockNumber="No";// : String
    private String blockNumberDetail;
    private String sendPush="No";// String
    private String sendPushDetail;
    private String sendMail="No";// String
    private String sendMailDetail;

    private String email; // Customer EMail
    private String mobileNo; // Customer Mobile No

    private String ruleName;

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getSendSms() {
        return sendSms;
    }

    public void setSendSms(String sendSms) {
        this.sendSms = sendSms;
    }

    public String getSendSmsDetail() {
        return sendSmsDetail;
    }

    public void setSendSmsDetail(String sendSmsDetail) {
        this.sendSmsDetail = sendSmsDetail;
    }

    public String getBlockCall() {
        return blockCall;
    }

    public void setBlockCall(String blockCall) {
        this.blockCall = blockCall;
    }

    public String getBlockCallDetail() {
        return blockCallDetail;
    }

    public void setBlockCallDetail(String blockCallDetail) {
        this.blockCallDetail = blockCallDetail;
    }

    public String getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(String blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String getBlockNumberDetail() {
        return blockNumberDetail;
    }

    public void setBlockNumberDetail(String blockNumberDetail) {
        this.blockNumberDetail = blockNumberDetail;
    }

    public String getSendPush() {
        return sendPush;
    }

    public void setSendPush(String sendPush) {
        this.sendPush = sendPush;
    }

    public String getSendPushDetail() {
        return sendPushDetail;
    }

    public void setSendPushDetail(String sendPushDetail) {
        this.sendPushDetail = sendPushDetail;
    }

    public String getSendMail() {
        return sendMail;
    }

    public void setSendMail(String sendMail) {
        this.sendMail = sendMail;
    }

    public String getSendMailDetail() {
        return sendMailDetail;
    }

    public void setSendMailDetail(String sendMailDetail) {
        this.sendMailDetail = sendMailDetail;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
}
