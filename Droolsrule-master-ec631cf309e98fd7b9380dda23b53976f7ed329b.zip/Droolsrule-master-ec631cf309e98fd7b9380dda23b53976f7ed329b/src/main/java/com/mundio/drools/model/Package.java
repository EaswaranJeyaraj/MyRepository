package com.mundio.drools.model;

import java.util.Date;

/**
 * Created by sinchan on 12/06/17.
 */
public class Package {

    private int packageID; // Package ID
    private double packageBalance;

    private double accPkgBalance; // Initial Balance, Divide the Value by 100 to
    // get the Exact Balance
    private String currCode;
    private String mCustCode;
    private int mBatchCode;
    private int mSerialCode;
    private int packageType; // To differentiate Call / SMS / GPRS
    private Date accPkgLastUpdate;
    private String pkgName; // Package Name
    private String pkgTariffClass; // Bundle Tariff Class
    private int packageTypeID;
    private int duration;
    private String ussdInfoText;
    private int flagToBuyBundle;
    private int daysValid;
    private Date expiredDate;
    private int expdateMode;


    public String getPkgName() {
        return pkgName;
    }

    public void setPkgName(String pkgName) {
        this.pkgName = pkgName;
    }

    public String getPkgTariffClass() {
        return pkgTariffClass;
    }

    public void setPkgTariffClass(String pkgTariffClass) {
        this.pkgTariffClass = pkgTariffClass;
    }

    public int getPackageTypeID() {
        return packageTypeID;
    }

    public void setPackageTypeID(int packageTypeID) {
        this.packageTypeID = packageTypeID;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getUssdInfoText() {
        return ussdInfoText;
    }

    public void setUssdInfoText(String ussdInfoText) {
        this.ussdInfoText = ussdInfoText;
    }

    public int getFlagToBuyBundle() {
        return flagToBuyBundle;
    }

    public void setFlagToBuyBundle(int flagToBuyBundle) {
        this.flagToBuyBundle = flagToBuyBundle;
    }

    public int getPackageID() {
        return packageID;
    }

    public void setPackageID(int packageID) {
        this.packageID = packageID;
    }

    public double getPackageBalance() {
        return packageBalance;
    }

    public void setPackageBalance(double packageBalance) {
        this.packageBalance = packageBalance;
    }

    public double getAccPkgBalance() {
        return accPkgBalance;
    }

    public void setAccPkgBalance(double accPkgBalance) {
        this.accPkgBalance = accPkgBalance;
    }

    public String getCurrCode() {
        return currCode;
    }

    public void setCurrCode(String currCode) {
        this.currCode = currCode;
    }

    public String getmCustCode() {
        return mCustCode;
    }

    public void setmCustCode(String mCustCode) {
        this.mCustCode = mCustCode;
    }

    public int getmBatchCode() {
        return mBatchCode;
    }

    public void setmBatchCode(int mBatchCode) {
        this.mBatchCode = mBatchCode;
    }

    public int getmSerialCode() {
        return mSerialCode;
    }

    public void setmSerialCode(int mSerialCode) {
        this.mSerialCode = mSerialCode;
    }

    public int getPackageType() {
        return packageType;
    }

    public void setPackageType(int packageType) {
        this.packageType = packageType;
    }

    public Date getAccPkgLastUpdate() {
        return accPkgLastUpdate;
    }

    public void setAccPkgLastUpdate(Date accPkgLastUpdate) {
        this.accPkgLastUpdate = accPkgLastUpdate;
    }

    public int getDaysValid() {
        return daysValid;
    }

    public void setDaysValid(int daysValid) {
        this.daysValid = daysValid;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public int getExpdateMode() {
        return expdateMode;
    }

    public void setExpdateMode(int expdateMode) {
        this.expdateMode = expdateMode;
    }

    @Override
    public String toString() {
        return "Package{" +
                "packageID=" + packageID +
                ", packageBalance=" + packageBalance +
                ", accPkgBalance=" + accPkgBalance +
                ", currCode='" + currCode + '\'' +
                ", mCustCode='" + mCustCode + '\'' +
                ", mBatchCode=" + mBatchCode +
                ", mSerialCode=" + mSerialCode +
                ", packageType=" + packageType +
                ", accPkgLastUpdate=" + accPkgLastUpdate +
                ", pkgName='" + pkgName + '\'' +
                ", pkgTariffClass='" + pkgTariffClass + '\'' +
                ", packageTypeID=" + packageTypeID +
                ", duration=" + duration +
                ", ussdInfoText='" + ussdInfoText + '\'' +
                ", flagToBuyBundle=" + flagToBuyBundle +
                ", daysValid=" + daysValid +
                ", expiredDate=" + expiredDate +
                ", expdateMode=" + expdateMode +
                '}';
    }
}