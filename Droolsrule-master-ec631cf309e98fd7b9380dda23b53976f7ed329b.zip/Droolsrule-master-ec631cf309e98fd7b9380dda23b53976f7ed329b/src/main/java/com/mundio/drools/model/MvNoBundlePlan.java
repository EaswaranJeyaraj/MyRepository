package com.mundio.drools.model;

import java.util.Date;

/**
 * Created by sinchan on 12/06/17.
 */
public class MvNoBundlePlan {


    private Date joinDate;
    private Date stopDate;
    private Date lastUpdate;
    private int payMode; // payment method for this process. 0: free payment 1:
    // debiting from master 2: debiting from CCDC 3:
    // free
    private Date startDate; // the startdate for each bundle subscription cycle
    private Date endDate; // the enddate for each bundle subscription cycle
    private int mvbpStatus; // status for each bundle on this user. 1: active 2:
    // inactive 3: suspended 4: need to renew/repay

    private int bundleID; // ID for Each Bundle
    private String siteCode; // To Differentiate the Country
    private String bundleName; // Name of the Bundle
    private double price; // Bundle Price
    private String currency; // Bundle Currency

    private String updateBy;
    private int status; // Bundle Status
    private int renewalMode; // Renewal Methods for the Bundle
    private int renewalDelay;
    private int mainBundleGroupID;
    private int familyGroupID;
    private int tariffClassGroupID;
    private int bundleGroupID;

    private int paymentFlag; // the payment flag that related to renewal


    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }
    public Date getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(Date joinDate) {
        this.joinDate = joinDate;
    }

    public Date getStopDate() {
        return stopDate;
    }

    public void setStopDate(Date stopDate) {
        this.stopDate = stopDate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getPayMode() {
        return payMode;
    }

    public void setPayMode(int payMode) {
        this.payMode = payMode;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getMvbpStatus() {
        return mvbpStatus;
    }

    public void setMvbpStatus(int mvbpStatus) {
        this.mvbpStatus = mvbpStatus;
    }

    public int getPaymentFlag() {
        return paymentFlag;
    }

    public void setPaymentFlag(int paymentFlag) {
        this.paymentFlag = paymentFlag;
    }

    public int getBundleID() {
        return bundleID;
    }

    public void setBundleID(int bundleID) {
        this.bundleID = bundleID;
    }

    public String getSiteCode() {
        return siteCode;
    }

    public void setSiteCode(String siteCode) {
        this.siteCode = siteCode;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getRenewalMode() {
        return renewalMode;
    }

    public void setRenewalMode(int renewalMode) {
        this.renewalMode = renewalMode;
    }

    public int getRenewalDelay() {
        return renewalDelay;
    }

    public void setRenewalDelay(int renewalDelay) {
        this.renewalDelay = renewalDelay;
    }

    public int getMainBundleGroupID() {
        return mainBundleGroupID;
    }

    public void setMainBundleGroupID(int mainBundleGroupID) {
        this.mainBundleGroupID = mainBundleGroupID;
    }

    public int getFamilyGroupID() {
        return familyGroupID;
    }

    public void setFamilyGroupID(int familyGroupID) {
        this.familyGroupID = familyGroupID;
    }

    public int getTariffClassGroupID() {
        return tariffClassGroupID;
    }

    public void setTariffClassGroupID(int tariffClassGroupID) {
        this.tariffClassGroupID = tariffClassGroupID;
    }

    public int getBundleGroupID() {
        return bundleGroupID;
    }

    public void setBundleGroupID(int bundleGroupID) {
        this.bundleGroupID = bundleGroupID;
    }

    @Override
    public String toString() {
        return "MvNoBundlePlan{" +
                "joinDate=" + joinDate +
                ", stopDate=" + stopDate +
                ", lastUpdate=" + lastUpdate +
                ", payMode=" + payMode +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", mvbpStatus=" + mvbpStatus +
                ", bundleID=" + bundleID +
                ", siteCode='" + siteCode + '\'' +
                ", bundleName='" + bundleName + '\'' +
                ", price=" + price +
                ", currency='" + currency + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", status=" + status +
                ", renewalMode=" + renewalMode +
                ", renewalDelay=" + renewalDelay +
                ", mainBundleGroupID=" + mainBundleGroupID +
                ", familyGroupID=" + familyGroupID +
                ", tariffClassGroupID=" + tariffClassGroupID +
                ", bundleGroupID=" + bundleGroupID +
                ", paymentFlag=" + paymentFlag +
                '}';
    }
}
