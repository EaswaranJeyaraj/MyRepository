package com.mundio.drools.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class BundleCases implements Serializable {


	/* Common Fields */


	private BundleEvent event;
	private Action action;


	// Final Bundle Columns

	// Subscriber SQL Table Name For Reference Purpose

	private int subscriberID; // Customer Subscriber ID
	private String firstName; // Customer First Name
	private String lastName; // Customer Last Name
	private String email; // Customer EMail
	private Date activationDate;

	private String iccID; // Unique ID for Customer
	private String mobileNo; // Customer Mobile No
	private String custCode;
	private int batchCode;
	private int serialCode;
	private Date renewStartDate;
	private Date renewDuedate;

	// account

	private String accTrffClass; // Master Tariff Class
	private double accBalance; // Current Balance, Divide the Value by 100 to
	// get the Exact Balance
	private double totalCons; // Data Consumed will be stored here
	private double monthLim;
	private double totalCost;
	private int accStatus;

	// Sim

	private int subscriberStatus; // Subscriber Status
	private Date firstUpdate; // Customer First Login Date

	private List<MvNoBundlePlan> bundles;


	private List<Package> packages;
	private List<TopupLog> logs;
	private List<BundleLog> bundlelogs;

	public List<BundleLog> getBundlelogs() {
		return bundlelogs;
	}


	public void setBundlelogs(List<BundleLog> bundlelogs) {
		this.bundlelogs = bundlelogs;
	}

	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}

	public int getSubscriberID() {
		return subscriberID;
	}

	public void setSubscriberID(int subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public String getIccID() {
		return iccID;
	}

	public void setIccID(String iccID) {
		this.iccID = iccID;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public int getBatchCode() {
		return batchCode;
	}

	public void setBatchCode(int batchCode) {
		this.batchCode = batchCode;
	}

	public int getSerialCode() {
		return serialCode;
	}

	public void setSerialCode(int serialCode) {
		this.serialCode = serialCode;
	}

	public Date getRenewStartDate() {
		return renewStartDate;
	}

	public void setRenewStartDate(Date renewStartDate) {
		this.renewStartDate = renewStartDate;
	}

	public Date getRenewDuedate() {
		return renewDuedate;
	}

	public void setRenewDuedate(Date renewDuedate) {
		this.renewDuedate = renewDuedate;
	}

	public String getAccTrffClass() {
		return accTrffClass;
	}

	public void setAccTrffClass(String accTrffClass) {
		this.accTrffClass = accTrffClass;
	}

	public double getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	public double getTotalCons() {
		return totalCons;
	}

	public void setTotalCons(double totalCons) {
		this.totalCons = totalCons;
	}

	public double getMonthLim() {
		return monthLim;
	}

	public void setMonthLim(double monthLim) {
		this.monthLim = monthLim;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public int getAccStatus() {
		return accStatus;
	}

	public void setAccStatus(int accStatus) {
		this.accStatus = accStatus;
	}

	public int getSubscriberStatus() {
		return subscriberStatus;
	}

	public void setSubscriberStatus(int subscriberStatus) {
		this.subscriberStatus = subscriberStatus;
	}

	public Date getFirstUpdate() {
		return firstUpdate;
	}

	public void setFirstUpdate(Date firstUpdate) {
		this.firstUpdate = firstUpdate;
	}

	public List<MvNoBundlePlan> getBundles() {
		return bundles;
	}

	public void setBundles(List<MvNoBundlePlan> bundles) {
		this.bundles = bundles;
	}

	public List<Package> getPackages() {
		return packages;
	}

	public void setPackages(List<Package> packages) {
		this.packages = packages;
	}

	public BundleEvent getEvent() {
		return event;
	}

	public void setEvent(BundleEvent event) {
		this.event = event;
	}

	public List<TopupLog> getLogs() {
		return logs;
	}

	public void setLogs(List<TopupLog> logs) {
		this.logs = logs;
	}

	@Override
	public String toString() {
		return "BundleCases{" +
				"event=" + event +
				", action=" + action +
				", subscriberID=" + subscriberID +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", email='" + email + '\'' +
				", activationDate=" + activationDate +
				", iccID='" + iccID + '\'' +
				", mobileNo='" + mobileNo + '\'' +
				", custCode='" + custCode + '\'' +
				", batchCode=" + batchCode +
				", serialCode=" + serialCode +
				", renewStartDate=" + renewStartDate +
				", renewDuedate=" + renewDuedate +
				", accTrffClass='" + accTrffClass + '\'' +
				", accBalance=" + accBalance +
				", totalCons=" + totalCons +
				", monthLim=" + monthLim +
				", totalCost=" + totalCost +
				", accStatus=" + accStatus +
				", subscriberStatus=" + subscriberStatus +
				", firstUpdate=" + firstUpdate +
				", bundles=" + bundles +
				", packages=" + packages +
				", logs=" + logs +
				", bundlelogs=" + bundlelogs +
				'}';
	}
}