package com.mundio.drools.controller;

import com.mundio.drools.model.Action;
import com.mundio.drools.model.BundleCases;
import com.mundio.drools.service.FactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created by sinchan on 12/09/17.
 */
@RequestMapping("/facts")
@RestController
public class FactController {
    @Autowired
    private FactService factService;

    //@CrossOrigin(origins = "*")
    @RequestMapping(value = "/bundle",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.POST)
    public ResponseEntity<Action> evalBundleCase(@RequestBody BundleCases facts){
        Action action = new Action();
        try {
            action = factService.fireRulesForBundleCase(facts);
        }catch (Exception e){
            return new ResponseEntity<Action>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<Action>(action,HttpStatus.OK);
    }
}
