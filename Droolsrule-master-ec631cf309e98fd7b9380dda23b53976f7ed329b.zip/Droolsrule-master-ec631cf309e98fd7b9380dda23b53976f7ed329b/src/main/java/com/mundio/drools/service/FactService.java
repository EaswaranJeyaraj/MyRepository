package com.mundio.drools.service;

import com.mundio.drools.model.Action;
import com.mundio.drools.model.BundleCases;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by sinchan on 12/09/17.
 */
@Service
public class FactService {

private static Logger logger = LoggerFactory.getLogger(FactService.class);
    @Autowired
    private  KieContainer kieContainer;




    public Action fireRulesForBundleCase(BundleCases fact){
        //Gson gson = new GsonFactoryBean().getObject();
        Action action = null;
        KieSession kieSession = kieContainer.newKieSession("rulesSession");

        logger.info("Mobile No : "+fact.getMobileNo());

        if(fact.getEvent() !=null)
            logger.info("Action Type : "+fact.getEvent().getActionType());

        kieSession.insert(fact);
        int noOfRulesFired = kieSession.fireAllRules();

        logger.info("No of rules fired : "+noOfRulesFired);
        System.out.print("No of rules fired: " + noOfRulesFired);

        kieSession.dispose();
        if(fact.getAction()==null){
            action = new Action();
            action.setBlockCall("No");
            action.setBlockNumber("No");
            action.setSendMail("No");
            action.setSendPush("No");
            action.setSendSms("No");
            action.setMobileNo(fact.getMobileNo());
            action.setEmail(fact.getEmail());
        }else{
            action = fact.getAction();
            logger.info("Rule Name : "+action.getRuleName());

        }
        return action;
    }
}
