package com.mundio.mat

import com.typesafe.config.ConfigFactory

/**
  * Created by sinchan on 15-01-2017.
  */
object ConfigReader {
  /** Loads all key/value pairs from the application configuration file. */
  val conf = ConfigFactory.load

  def getConfigValueAsString(propertName:String):String = {
    lazy val seedLocations = conf.getString(propertName)
    seedLocations
  }
}
