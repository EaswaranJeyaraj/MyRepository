package com.mundio.mat

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.streaming.dstream.InputDStream
import org.json4s.native.Json
import org.json4s.DefaultFormats
import org.json4s._
import org.json4s.native.JsonMethods._

/**
  * Created by sinchan on 12-01-2017.
  */
object GenericUtility {

  var session: SparkSession = null


  def cleanly[A,B](resource: => A)(cleanup: A => Unit)(code: A => B): Either[Exception,B] = {
    try {
      val r = resource
      try { Right(code(r)) } finally { cleanup(r) }
    }
    catch { case e: Exception => Left(e) }
  }

  def checkNulltoDefault(param: Any = null) {
    val paramOrDefault = Option(param).getOrElse("No")
  }
}
