package com.mundio.rules;

import java.io.Serializable;
import java.util.Date;

public class CustomerFact implements Serializable {


	/* Common Fields */
	private String sendsms = "No";
	private String sendsmsdetail;
	private String blockcall ="No";
	private String blockcalldetail;
	private String blocknumber ="No";// : String
	private String blocknumberdetail;
	private String sendpush ="No";// String
	private String sendpushdetail;

	public String getSendsms() {
		return sendsms;
	}

	public void setSendsms(String sendsms) {
		this.sendsms = sendsms;
	}

	public String getSendsmsdetail() {
		return sendsmsdetail;
	}

	public void setSendsmsdetail(String sendsmsdetail) {
		this.sendsmsdetail = sendsmsdetail;
	}

	public String getBlockcall() {
		return blockcall;
	}

	public void setBlockcall(String blockcall) {
		this.blockcall = blockcall;
	}

	public String getBlockcalldetail() {
		return blockcalldetail;
	}

	public void setBlockcalldetail(String blockcalldetail) {
		this.blockcalldetail = blockcalldetail;
	}

	public String getBlocknumber() {
		return blocknumber;
	}

	public void setBlocknumber(String blocknumber) {
		this.blocknumber = blocknumber;
	}

	public String getBlocknumberdetail() {
		return blocknumberdetail;
	}

	public void setBlocknumberdetail(String blocknumberdetail) {
		this.blocknumberdetail = blocknumberdetail;
	}

	public String getSendpush() {
		return sendpush;
	}

	public void setSendpush(String sendpush) {
		this.sendpush = sendpush;
	}

	public String getSendpushdetail() {
		return sendpushdetail;
	}

	public void setSendpushdetail(String sendpushdetail) {
		this.sendpushdetail = sendpushdetail;
	}

	public String getSendmail() {
		return sendmail;
	}

	public void setSendmail(String sendmail) {
		this.sendmail = sendmail;
	}

	public String getSendmaildetail() {
		return sendmaildetail;
	}

	public void setSendmaildetail(String sendmaildetail) {
		this.sendmaildetail = sendmaildetail;
	}

	private String sendmail;// String
	private String sendmaildetail;



	/* Other Fields */

	/* BUNDLE FACT TABLE USE CASE */

	/* Subscriber */

	private int subscriberID;
	private String firstName;
	private String lastName;
	private String city;
	private String postCode;
	private String state;
	private String countryCode;
	private String mobilePhone;
	private String email;
	private int subscriberType;
	private int packageType;
	private String personNumber;
	private String mobileNo;
	private Date createDate;
	private String subscriberChannel;
	private int bySMS;
	private int byEmail;
	private Date activationDate;
	private int activateBy;
	private String simtype;

	

	/* Mvno_bundle_plan Reference SQL Table Name*/ 


	private String iccid;
	private String mvnoMobileNo; // Customer Mobile No
	private int bundleID;
	private int status; // Status 1 for Active Customers
	private Date joinDate;
	private Date stopDate;
	private Date lastUpdate;
	private int paymode;
	private String renewalMode;
	private String renewalDelay;
	private Date startDate; // Bundle Subscribed Date
	private Date endDate; // Bundle End Date
	private String updateby;
	private int datemode;
	private Date lastPay;
	private Date duePay;
	private Date ctrStartDate;
	private Date ctrEndDate;
	private Date overrideTariffclassActdate;
	private Date firstusageDate;

	/* Bundle Plan Reference SQL Table Name */

	private int bpBundleID;
	private String siteCode;
	private String name; // Name of the Bundle
	private double price;
	private String currency;
	private int bundleStatus;
	private int payModeDefault;
	private int bprenewalMode;
	private int bprenewalDelay;
	private String description;
	private Date lastUpd;
	private String accessNumber;
	private int paymentDelay;
	private int topUpFlag;
	private int serviceFlag;
	private int mainBundleGroupID;
	private int tariffClassGroupID;
	private int renewDateMode;
	private int bundleGroupID;
	private int limitBalanceMode;
	private double limitBalanceAmount;
	private double newPrice;
	private Date newpriceStartdate;
	private int discStartDateMode;
	private Date discStartDate;
	private int packageGroupIDDisable;
	private Date firstUpdateFr;
	private Date firstUpdateTo;

	/* Subscriber */

	
	public int getSubscriberID() {
		return subscriberID;
	}

	public void setSubscriberID(int subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getSubscriberType() {
		return subscriberType;
	}

	public void setSubscriberType(int subscriberType) {
		this.subscriberType = subscriberType;
	}

	public int getPackageType() {
		return packageType;
	}

	public void setPackageType(int packageType) {
		this.packageType = packageType;
	}

	public String getPersonNumber() {
		return personNumber;
	}

	public void setPersonNumber(String personNumber) {
		this.personNumber = personNumber;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getSubscriberChannel() {
		return subscriberChannel;
	}

	public void setSubscriberChannel(String subscriberChannel) {
		this.subscriberChannel = subscriberChannel;
	}

	public int getBySMS() {
		return bySMS;
	}

	public void setBySMS(int bySMS) {
		this.bySMS = bySMS;
	}

	public int getByEmail() {
		return byEmail;
	}

	public void setByEmail(int byEmail) {
		this.byEmail = byEmail;
	}

	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public int getActivateBy() {
		return activateBy;
	}

	public void setActivateBy(int activateBy) {
		this.activateBy = activateBy;
	}

	public String getSimtype() {
		return simtype;
	}

	public void setSimtype(String simtype) {
		this.simtype = simtype;
	}
	
	
	/* Mvno_bundle_plan */
	
	
	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public String getMvnoMobileNo() {
		return mvnoMobileNo;
	}

	public void setMvnoMobileNo(String mvnoMobileNo) {
		this.mvnoMobileNo = mvnoMobileNo;
	}

	public int getBundleID() {
		return bundleID;
	}

	public void setBundleID(int bundleID) {
		this.bundleID = bundleID;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public Date getStopDate() {
		return stopDate;
	}

	public void setStopDate(Date stopDate) {
		this.stopDate = stopDate;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getPaymode() {
		return paymode;
	}

	public void setPaymode(int paymode) {
		this.paymode = paymode;
	}

	public String getRenewalMode() {
		return renewalMode;
	}

	public void setRenewalMode(String renewalMode) {
		this.renewalMode = renewalMode;
	}

	public String getRenewalDelay() {
		return renewalDelay;
	}

	public void setRenewalDelay(String renewalDelay) {
		this.renewalDelay = renewalDelay;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getUpdateby() {
		return updateby;
	}

	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}

	public int getDatemode() {
		return datemode;
	}

	public void setDatemode(int datemode) {
		this.datemode = datemode;
	}

	public Date getLastPay() {
		return lastPay;
	}

	public void setLastPay(Date lastPay) {
		this.lastPay = lastPay;
	}

	public Date getDuePay() {
		return duePay;
	}

	public void setDuePay(Date duePay) {
		this.duePay = duePay;
	}

	public Date getCtrStartDate() {
		return ctrStartDate;
	}

	public void setCtrStartDate(Date ctrStartDate) {
		this.ctrStartDate = ctrStartDate;
	}

	public Date getCtrEndDate() {
		return ctrEndDate;
	}

	public void setCtrEndDate(Date ctrEndDate) {
		this.ctrEndDate = ctrEndDate;
	}

	public Date getOverrideTariffclassActdate() {
		return overrideTariffclassActdate;
	}

	public void setOverrideTariffclassActdate(Date overrideTariffclassActdate) {
		this.overrideTariffclassActdate = overrideTariffclassActdate;
	}

	public Date getFirstusageDate() {
		return firstusageDate;
	}

	public void setFirstusageDate(Date firstusageDate) {
		this.firstusageDate = firstusageDate;
	}
	
	
	
	/* Bundle Plan */
	
	
	
	public int getBpBundleID() {
		return bpBundleID;
	}

	public void setBpBundleID(int bpBundleID) {
		this.bpBundleID = bpBundleID;
	}

	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getBundleStatus() {
		return bundleStatus;
	}

	public void setBundleStatus(int bundleStatus) {
		this.bundleStatus = bundleStatus;
	}

	public int getPayModeDefault() {
		return payModeDefault;
	}

	public void setPayModeDefault(int payModeDefault) {
		this.payModeDefault = payModeDefault;
	}

	public int getBprenewalMode() {
		return bprenewalMode;
	}

	public void setBprenewalMode(int bprenewalMode) {
		this.bprenewalMode = bprenewalMode;
	}

	public int getBprenewalDelay() {
		return bprenewalDelay;
	}

	public void setBprenewalDelay(int bprenewalDelay) {
		this.bprenewalDelay = bprenewalDelay;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getLastUpd() {
		return lastUpd;
	}

	public void setLastUpd(Date lastUpd) {
		this.lastUpd = lastUpd;
	}

	public String getAccessNumber() {
		return accessNumber;
	}

	public void setAccessNumber(String accessNumber) {
		this.accessNumber = accessNumber;
	}

	public int getPaymentDelay() {
		return paymentDelay;
	}

	public void setPaymentDelay(int paymentDelay) {
		this.paymentDelay = paymentDelay;
	}

	public int getTopUpFlag() {
		return topUpFlag;
	}

	public void setTopUpFlag(int topUpFlag) {
		this.topUpFlag = topUpFlag;
	}

	public int getServiceFlag() {
		return serviceFlag;
	}

	public void setServiceFlag(int serviceFlag) {
		this.serviceFlag = serviceFlag;
	}

	public int getMainBundleGroupID() {
		return mainBundleGroupID;
	}

	public void setMainBundleGroupID(int mainBundleGroupID) {
		this.mainBundleGroupID = mainBundleGroupID;
	}

	public int getTariffClassGroupID() {
		return tariffClassGroupID;
	}

	public void setTariffClassGroupID(int tariffClassGroupID) {
		this.tariffClassGroupID = tariffClassGroupID;
	}

	public int getRenewDateMode() {
		return renewDateMode;
	}

	public void setRenewDateMode(int renewDateMode) {
		this.renewDateMode = renewDateMode;
	}

	public int getBundleGroupID() {
		return bundleGroupID;
	}

	public void setBundleGroupID(int bundleGroupID) {
		this.bundleGroupID = bundleGroupID;
	}

	public int getLimitBalanceMode() {
		return limitBalanceMode;
	}

	public void setLimitBalanceMode(int limitBalanceMode) {
		this.limitBalanceMode = limitBalanceMode;
	}

	public double getLimitBalanceAmount() {
		return limitBalanceAmount;
	}

	public void setLimitBalanceAmount(double limitBalanceAmount) {
		this.limitBalanceAmount = limitBalanceAmount;
	}

	public double getNewPrice() {
		return newPrice;
	}

	public void setNewPrice(double newPrice) {
		this.newPrice = newPrice;
	}

	public Date getNewpriceStartdate() {
		return newpriceStartdate;
	}

	public void setNewpriceStartdate(Date newpriceStartdate) {
		this.newpriceStartdate = newpriceStartdate;
	}

	public int getDiscStartDateMode() {
		return discStartDateMode;
	}

	public void setDiscStartDateMode(int discStartDateMode) {
		this.discStartDateMode = discStartDateMode;
	}

	public Date getDiscStartDate() {
		return discStartDate;
	}

	public void setDiscStartDate(Date discStartDate) {
		this.discStartDate = discStartDate;
	}

	public int getPackageGroupIDDisable() {
		return packageGroupIDDisable;
	}

	public void setPackageGroupIDDisable(int packageGroupIDDisable) {
		this.packageGroupIDDisable = packageGroupIDDisable;
	}

    public Date getFirstUpdateFr() {
        return firstUpdateFr;
    }

    public void setFirstUpdateFr(Date firstUpdateFr) {
        this.firstUpdateFr = firstUpdateFr;
    }

    public Date getFirstUpdateTo() {
        return firstUpdateTo;
    }

    public void setFirstUpdateTo(Date firstUpdateTo) {
        this.firstUpdateTo = firstUpdateTo;
    }

	

}
