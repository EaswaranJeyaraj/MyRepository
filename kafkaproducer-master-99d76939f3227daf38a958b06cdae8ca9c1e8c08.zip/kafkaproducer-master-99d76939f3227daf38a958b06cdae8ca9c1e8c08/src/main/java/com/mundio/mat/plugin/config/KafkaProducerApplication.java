package com.mundio.mat.plugin.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Created by sinchan on 22/06/17.
 */
@SpringBootApplication
@EnableScheduling
@ComponentScan({"com.mundio.mat.plugin"})
public class KafkaProducerApplication extends SpringBootServletInitializer {

    public static void main(String args[]){
        SpringApplication application = new SpringApplication(KafkaProducerApplication.class);
        application.run(args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(KafkaProducerApplication.class);
    }
}
