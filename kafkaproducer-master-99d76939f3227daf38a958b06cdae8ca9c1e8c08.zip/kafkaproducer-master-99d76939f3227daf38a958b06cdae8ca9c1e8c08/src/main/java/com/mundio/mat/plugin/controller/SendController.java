package com.mundio.mat.plugin.controller;

import com.mundio.mat.plugin.domain.ProducerRequest;
import com.mundio.mat.plugin.service.SendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created by sinchan on 22/06/17.
 */
@RequestMapping("/producer")
@RestController
public class SendController {

    @Autowired
    private SendService sendService;

    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/send",consumes = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.POST)
    public ResponseEntity<String> sendMessage(@RequestBody ProducerRequest producerRequest){
        try {
            sendService.send(producerRequest.getKey(), producerRequest.getTopic(), producerRequest.getMessage());
        }catch (Exception ex){
            return new ResponseEntity(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(HttpStatus.ACCEPTED);
    }
}
