package com.mundio.mat.plugin.domain;

/**
 * Created by sinchan on 22/06/17.
 */
public class ProducerRequest {

    private String key;
    private String topic;
    private String message;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
